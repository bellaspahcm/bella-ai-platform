# Preschool Chain E2E — resume checkpoint, 23 October 2026

Worktree: `C:/Users/DELL/.codex/worktrees/preschool-chain-main-integration/BELLA SPA ERP`.
Branch: `codex/preschool-chain-main-integration-20261023`; HEAD `80e13ea92ee70742d26cd890a45aaa94d8fc7494` plus preserved staged/unstaged/untracked integration. No commit/push/PR/merge/deploy was performed. Never reset either this worktree or the original dirty Chain worktree.

Final source manifest: `FINAL_SOURCE.json`, SHA256 `acbc5d8fd348e8041482ddd3ed9cbc925384d191838221fb50a2dfcde4baad68` (104 changed/new source/test/migration paths). Final browser runtime copy and original source were rechecked and matched. The runtime copy is a proof launcher on D: using the existing dependency junction; it does not replace the authoritative Git worktree. Credentials are read only from approved environment configuration and were not persisted.

## Closed in executed Non-Production scope

- Applied exactly the human-approved 20-file migration bundle on target `bmnbqbcdbuklhopfbopv`, in one transaction with source-bound ledger entries. Before/after digest equality covered 242 existing public tables / 275,636 rows at migration commit. Preserved 133 old history entries and defaults. Effective TRUNCATE denied for all 44 reviewed role/table pairs. See `TARGET_APPLY_RESULT.json`, `TARGET_BEFORE.json`, `TARGET_AFTER.json`, and the exact executor/source plan.
- `db:migration:check` against `origin/main` PASS for new diff; 419 historical pending baseline versions remain disclosed and unreconciled. This is not full historical schema parity.
- Restored Preschool Attendance's Product transaction boundary through the public contract, retaining assignment locks and final authorization; 81 focused contract/Product/UI/API tests PASS.
- Fixed admission public-error translation after real HTTP returned 500 for payload conflict. Product/route regression: 25 PASS. Actual HTTP now returns 409. Two initial concurrent admission requests and later retries returned the same canonical student/enrollment IDs; SQL found one student, enrollment and durable enrollment event.
- Connected all existing Finance payment entry points to the durable dialog. The general invoice picker performs no payment write; pending operation key/payload takes precedence. 57 relevant Finance/API tests PASS. Final TypeScript PASS with zero diagnostics; ESLint and diff checks PASS. Earlier environment/generated-types/selector failures are retained.
- Real Finance HTTP: read → compile → issue → payment; invalid tenant/branch denied with unchanged financial state; discard response after real commit → restart Next process → retry/concurrent retry → same canonical payment/receipt; changed payload → 409. Recorded in `http-2026-10-23T02-46-57-584Z/HTTP_RESULTS.json` with its earlier source fingerprint and explicit scope.
- Final-source browser proof: real accountant, explicit branch selection, payment through UI, real server/DB commit, aborted browser response, full navigation/reload, retained operation key and immutable amount, canonical recovery, no duplicate payment/receipt. See `http-2026-10-23T03-04-42-694Z/HTTP_RESULTS.json` and the two screenshots. Source/runtime hashes reverified.

## Open blockers and limits

1. Attendance POST succeeded and direct/foreign callers were denied, but GET roster failed because canonical `edu_preschool_pickup_handover_events` is absent. The original SQL dependency closure missed this API-reader dependency. Exact one-file target extension is prepared in `HANDOVER_PREREQUISITE_SCOPE.md`; approval is still pending. Do not apply it until the user explicitly approves this extension. It is outside the approved 20-file allowlist. No fallback roster or fabricated data was added.
2. Post-test integrity check: history, functions, ACL/RLS, policies and defaults remain unchanged, but five existing table aggregate digests/counts differ after excluding all eight run-owned tenants. `audit_logs` +16 rows; `auto_customer_profiles` +4; `customers` +4; `tenants` +4; `users` +2. A bounded read-only check found four other tenants created during this shared-target window. Attribution of all changes and preservation of every original row remain NOT_PROVEN. Keep the raw gate `FAIL_AGGREGATE_DRIFT_UNATTRIBUTED`; do not relabel it PASS or assume Finance caused it. No data cleanup/repair was performed. See `POST_VERIFICATION_INTEGRITY.json` and `SHARED_TARGET_DRIFT_DIAGNOSIS.json`.
3. Four required remote checks on the exact candidate, independent review, full migration/operational parity and release/rollback acceptance remain NOT_PROVEN. Existing local proof does not replace them. No operational enrollment event consumer was established; downstream processing remains NOT_PROVEN.

## Next action

Resolve the pending one-file handover target approval and establish an exclusive verification window or authoritative attribution for shared-target drift before sealing data preservation. Resume existing canonical fixture IDs; do not repeat already-proven payment/admission writes or reset identities/history. A run-owned fixture can be signed in through an admin-generated link without sending email or persisting credentials, as implemented in the existing resume harness. Never use an unrelated tenant or Production.

`FINANCE_HTTP_RECOVERY = PASS_SCOPED_FOR_EXECUTED_CASES`  
`FINANCE_BROWSER_RECOVERY = PASS_SCOPED_FOR_EXECUTED_CASES`  
`ATTENDANCE_ROSTER = BLOCKED_MISSING_PREREQUISITE`  
`POST_TEST_EXISTING_DATA = FAIL_AGGREGATE_DRIFT_UNATTRIBUTED`  
`DELIVERY = HOLD`  
`FULL_CHAIN_GO_LIVE = NOT_PROVEN`

Full machine-readable status and exact evidence references: `CHECKPOINT.json`. Preserve every failed packet; a later PASS does not rewrite historical failure evidence.
