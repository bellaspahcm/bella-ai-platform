const fs=require('node:fs'),path=require('node:path');const h=require('./run-target-http.cjs');const {signInFixture}=require('./run-finance-resume.cjs');
(async()=>{let browser;const logs=[];try{
  await h.db.connect();const accountant=await signInFixture('accountant');h.prepareRuntime();await h.startServer();
  browser=await require('playwright').chromium.launch({headless:true});const context=await browser.newContext({viewport:{width:1440,height:1100}});
  await context.addCookies(Array.from(accountant.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));
  const page=await context.newPage();page.on('console',m=>{if(['error','warning'].includes(m.type()))logs.push({type:m.type(),message:m.text().slice(0,400)});});page.on('pageerror',e=>logs.push({type:'pageerror',message:e.message.slice(0,700)}));page.on('response',r=>{if(r.status()>=400)logs.push({type:'http',status:r.status(),url:r.url().split('?')[0]});});
  await page.goto(h.origin+'/dashboard/education/finance?tab=invoices',{waitUntil:'domcontentloaded',timeout:120000});
  const {expect}=require('@playwright/test');const branch=page.getByRole('combobox',{name:'Cơ sở tài chính'});
  await expect(branch).toBeEnabled({timeout:90000});await branch.click();
  const response=page.waitForResponse(r=>r.url().includes('/api/education/finance?branchId='),{timeout:30000});
  await page.getByRole('listbox').getByRole('button',{name:'Controlled Chain branch A',exact:true}).click();
  const scoped=await response;const scopedData=await scoped.json();
  await expect(page.getByText('Đang tải hoặc xử lý dữ liệu tài chính…')).toBeHidden({timeout:30000});
  logs.push({type:'scoped-finance-result',status:scoped.status(),keys:Object.keys(scopedData),invoices:scopedData.invoices?.map(i=>({id:i.id,invoiceStatus:i.invoiceStatus,settlementStatus:i.settlementStatus,outstandingAmount:i.outstandingAmount}))});
  const result={url:page.url(),body:(await page.locator('body').innerText()).slice(0,2400),logs};fs.writeFileSync(path.join(h.directory,'BROWSER_DIAGNOSIS.json'),JSON.stringify(result,null,2));await page.screenshot({path:path.join(h.directory,'BROWSER_DIAGNOSIS.png'),fullPage:true});console.log(JSON.stringify(result));
}catch(e){console.error(JSON.stringify({error:e.message}));process.exitCode=1;}finally{if(browser)await browser.close();await h.stopServer();await h.db.end();console.log(JSON.stringify({packet:h.directory}));}})();
