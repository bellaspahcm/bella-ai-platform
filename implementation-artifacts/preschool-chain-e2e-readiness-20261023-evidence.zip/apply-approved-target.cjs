// One approved E2E bundle, not a general migration runner. No environment fallback.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Client } = require('pg');
const { parse } = require('dotenv');
const packet = __dirname;
const root = path.resolve(packet, '../..');
const plan = JSON.parse(fs.readFileSync(path.join(packet, 'TARGET_APPLY_PLAN.json')));
const target = 'bmnbqbcdbuklhopfbopv';
const resultFile = path.join(packet, 'TARGET_APPLY_RESULT.json');
if (fs.existsSync(resultFile)) throw new Error('EXISTING_RESULT_REQUIRES_RECONCILIATION_BEFORE_RETRY');
if (plan.target !== target || plan.manifest.length !== 20 || plan.unresolvedNamedReferences.length) {
  throw new Error('APPROVED_PLAN_INVALID');
}
const approved = { at: new Date().toISOString(), authority: 'Human reply: Duyet dung scope E2E nay',
  scope: 'TARGET_APPLY_SCOPE.md', target, delivery: false };
fs.writeFileSync(path.join(packet, 'TARGET_APPROVAL.json'), JSON.stringify(approved, null, 2), { flag: 'wx' });
const env = parse(fs.readFileSync('D:/Antigravity/Projects/BELLA SPA ERP/.env.e2e'));
const dbUrl = env.DATABASE_EXECUTOR_URL_TEST?.trim();
if (!dbUrl) throw new Error('E2E_EXECUTOR_REQUIRED');
const url = new URL(dbUrl);
if (!['postgres:', 'postgresql:'].includes(url.protocol)
  || (!url.hostname.includes(target) && !decodeURIComponent(url.username).endsWith('.' + target))) {
  throw new Error('TARGET_GUARD_DENIED');
}
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const quote = name => '"' + name.replaceAll('"', '""') + '"';
const files = plan.manifest.map(m => {
  const source = fs.readFileSync(path.join(root, 'supabase/migrations', m.file), 'utf8');
  if (hash(source) !== m.sha256) throw new Error('SOURCE_HASH_MISMATCH_' + m.version);
  const begins = [...source.matchAll(/^\s*BEGIN;\s*$/gm)].length;
  const commits = [...source.matchAll(/^\s*COMMIT;\s*$/gm)].length;
  if (begins !== commits || begins > 1) throw new Error('TRANSACTION_WRAPPER_UNEXPECTED_' + m.version);
  const sql = source.replace(/^\s*BEGIN;\s*$/gm, '').replace(/^\s*COMMIT;\s*$/gm, '');
  return { ...m, sql, executionSha256: hash(sql), removedOuterTransactionWrapper: begins === 1 };
});
const client = new Client({ connectionString: dbUrl, ssl: { rejectUnauthorized: false }, connectionTimeoutMillis: 15000 });
async function metadata() {
  const queries = {
    history: 'SELECT version,name,md5(statements::text) AS statements_md5 FROM supabase_migrations.schema_migrations ORDER BY version',
    tables: "SELECT c.relname AS name,c.relrowsecurity,c.relforcerowsecurity,c.relacl::text AS acl FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY 1",
    policies: "SELECT tablename,policyname,roles,cmd,qual,with_check FROM pg_policies WHERE schemaname='public' ORDER BY 1,2",
    defaults: 'SELECT defaclrole::regrole::text AS owner,defaclnamespace::regnamespace::text AS schema,defaclobjtype,defaclacl::text FROM pg_default_acl ORDER BY 1,2,3',
    functions: "SELECT p.proname AS name,pg_get_function_identity_arguments(p.oid) AS args,p.proacl::text AS acl,md5(pg_get_functiondef(p.oid)) AS definition_md5 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.prokind='f' ORDER BY 1,2",
  };
  const state = {};
  for (const [name, query] of Object.entries(queries)) state[name] = (await client.query(query)).rows;
  return state;
}
async function digestTables(tables) {
  const results = [];
  for (const { name } of tables) {
    const row = (await client.query(`SELECT count(*)::text AS count,md5(coalesce(string_agg(row_digest,'' ORDER BY row_digest),'')) AS digest FROM (SELECT md5(to_jsonb(t)::text) AS row_digest FROM public.${quote(name)} t) q`)).rows[0];
    results.push({ name, ...row });
  }
  return results;
}
async function truncateState() {
  const rows = [];
  for (const name of plan.proposedTruncateScope) {
    for (const role of ['anon', 'authenticated']) {
      const result = (await client.query('SELECT has_table_privilege($1,$2,\'TRUNCATE\') AS effective', [role, name])).rows[0];
      rows.push({ table: name, role, ...result });
    }
  }
  return rows;
}
async function main() {
  let committed = false, before;
  const executed = [];
  try {
    await client.connect();
    await client.query('BEGIN');
    await client.query("SET LOCAL lock_timeout='5s'");
    await client.query("SET LOCAL statement_timeout='45s'");
    await client.query("SELECT pg_advisory_xact_lock(hashtextextended('bella:preschool:e2e-approved-chain-bundle:20261023',0))");
    before = await metadata();
    const initial = JSON.parse(fs.readFileSync(path.join(packet, 'TARGET_METADATA.json')));
    if (before.history.length !== initial.history.length
      || before.history.some((h, i) => h.version !== initial.history[i].version)) throw new Error('HISTORY_CHANGED_SINCE_APPROVAL_PREFLIGHT');
    for (const table of plan.newTables) {
      if ((await client.query('SELECT to_regclass($1) AS object', [table])).rows[0].object) throw new Error('PLANNED_NEW_TABLE_ALREADY_EXISTS_' + table);
    }
    before.data = await digestTables(before.tables);
    fs.writeFileSync(path.join(packet, 'TARGET_BEFORE.json'), JSON.stringify(before, null, 2), { flag: 'wx' });
    for (const file of files) {
      await client.query(file.sql);
      await client.query('INSERT INTO supabase_migrations.schema_migrations(version,name,statements) VALUES($1,$2,$3::text[])',
        [file.version, file.file.replace(/^\d+_/, '').replace(/\.sql$/, ''), [file.sql]]);
      executed.push({ file: file.file, sha256: file.sha256, executionSha256: file.executionSha256,
        removedOuterTransactionWrapper: file.removedOuterTransactionWrapper });
    }
    const aclBefore = await truncateState();
    for (const name of plan.proposedTruncateScope) {
      await client.query(`REVOKE TRUNCATE ON TABLE public.${quote(name.replace(/^public\./, ''))} FROM anon,authenticated`);
    }
    const aclAfter = await truncateState();
    if (aclAfter.some(r => r.effective)) throw new Error('EFFECTIVE_TRUNCATE_REMAINS_NO_AUTHORITY_TO_CHANGE_INHERITANCE');
    const after = await metadata();
    after.data = await digestTables(before.tables);
    if (JSON.stringify(before.data) !== JSON.stringify(after.data)) throw new Error('EXISTING_DATA_CHANGED_ROLLBACK');
    if (JSON.stringify(before.defaults) !== JSON.stringify(after.defaults)) throw new Error('DEFAULT_PRIVILEGES_CHANGED_ROLLBACK');
    if (after.history.length !== before.history.length + 20
      || before.history.some(old => JSON.stringify(after.history.find(h => h.version === old.version)) !== JSON.stringify(old))) {
      throw new Error('HISTORY_OUTSIDE_BUNDLE_CHANGED_ROLLBACK');
    }
    const allowedTables = new Set(['preschool_chain_course_branch_assignments','preschool_chain_enrollment_branch_assignments','edu_enrollments','edu_attendance_daily_state']);
    for (const old of before.tables) {
      const current = after.tables.find(t => t.name === old.name);
      if (!allowedTables.has(old.name) && JSON.stringify(current) !== JSON.stringify(old)) throw new Error('OUT_OF_SCOPE_TABLE_METADATA_CHANGED_' + old.name);
    }
    const allowedPolicies = new Set(['preschool_chain_course_branch_assignments','preschool_chain_enrollment_branch_assignments']);
    for (const old of before.policies) {
      const current = after.policies.find(p => p.tablename === old.tablename && p.policyname === old.policyname);
      if (!allowedPolicies.has(old.tablename) && JSON.stringify(current) !== JSON.stringify(old)) throw new Error('OUT_OF_SCOPE_POLICY_CHANGED_' + old.tablename);
    }
    for (const old of before.functions) {
      const current = after.functions.find(f => f.name === old.name && f.args === old.args);
      if (JSON.stringify(current) !== JSON.stringify(old)) throw new Error('PREEXISTING_FUNCTION_CHANGED_' + old.name);
    }
    await client.query("NOTIFY pgrst, 'reload schema'");
    await client.query('COMMIT');
    committed = true;
    fs.writeFileSync(path.join(packet, 'TARGET_AFTER.json'), JSON.stringify({ ...after, truncateBefore: aclBefore, truncateAfter: aclAfter }, null, 2), { flag: 'wx' });
    const finalHistory = (await client.query('SELECT version FROM supabase_migrations.schema_migrations WHERE version=ANY($1::text[]) ORDER BY version', [files.map(f => f.version)])).rows;
    if (finalHistory.length !== 20) throw new Error('POST_COMMIT_HISTORY_READBACK_INCOMPLETE');
    const result = { at: new Date().toISOString(), target, result: 'PASS_SCOPED', committed, executed,
      applied: finalHistory, preservedHistoryEntries: before.history.length, preservedTables: before.data.length,
      preservedRows: before.data.reduce((n, r) => n + Number(r.count), 0), existingData: 'UNCHANGED_BY_DIGEST',
      defaults: 'UNCHANGED', effectiveTruncateDenied: aclAfter.length, fullChainGoLive: 'NOT_PROVEN' };
    fs.writeFileSync(resultFile, JSON.stringify(result, null, 2), { flag: 'wx' });
    console.log(JSON.stringify({ result: result.result, applied: finalHistory.length, committed, preservedTables: result.preservedTables,
      preservedRows: result.preservedRows, effectiveTruncateDenied: result.effectiveTruncateDenied }));
  } catch (error) {
    if (!committed) await client.query('ROLLBACK').catch(() => {});
    const result = { at: new Date().toISOString(), target, result: committed ? 'POST_COMMIT_VERIFICATION_FAILED_HOLD' : 'FAIL_ROLLED_BACK',
      committed, attempted: executed.map(f => f.file), code: error.code ?? null,
      error: String(error.message).replace(/postgres(?:ql)?:\/\/[^\s]+/g, '[REDACTED_DB_URL]').slice(0, 700) };
    if (before && !committed) {
      const restored = await metadata();
      const data = await digestTables(before.tables);
      result.rollbackMetadataUnchanged = ['history','tables','policies','defaults','functions'].every(k => JSON.stringify(before[k]) === JSON.stringify(restored[k]));
      result.rollbackDataUnchanged = JSON.stringify(before.data) === JSON.stringify(data);
    }
    fs.writeFileSync(resultFile, JSON.stringify(result, null, 2), { flag: 'wx' });
    console.error(JSON.stringify(result));
    process.exitCode = 1;
  } finally { await client.end(); }
}
main().catch(error => { console.error(JSON.stringify({ code: error.code ?? null, message: 'EXECUTOR_FAILED_REQUIRES_READBACK' })); process.exitCode = 1; });
