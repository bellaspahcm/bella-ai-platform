const fs=require('node:fs'),path=require('node:path');const h=require('./run-target-http.cjs');const {signInFixture,browserPayment}=require('./run-finance-resume.cjs');
(async()=>{try{await h.db.connect();const accountant=await signInFixture('accountant');const invoices=await h.rows('edu_fin_invoices');if(invoices.length!==1)throw new Error('RUN_OWNED_INVOICE_NOT_UNIQUE');
  h.prepareRuntime();await h.startServer();await browserPayment(accountant,invoices[0].id);
}catch(error){h.observations.push({name:'browser_finance',result:'FAIL',error:error.message.slice(0,1600)});console.error(JSON.stringify(h.observations.at(-1)));process.exitCode=1;}
finally{await h.stopServer();await h.db.end();h.save();console.log(JSON.stringify({packet:h.directory}));}})();
