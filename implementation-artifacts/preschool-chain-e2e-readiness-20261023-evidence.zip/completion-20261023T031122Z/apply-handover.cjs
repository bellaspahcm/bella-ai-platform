const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {Client}=require('pg');const config=require('../target-env.cjs');
const root=path.resolve(__dirname,'../../..'),file='supabase/migrations/20260927030000_preschool_safe_pickup_handover_events.sql';
const sql=fs.readFileSync(path.join(root,file),'utf8'),sha256=crypto.createHash('sha256').update(sql).digest('hex');
assert.equal(sha256,'17d5ca4cf8b5265fb36e4e93f4c86ca5254701a1745d039c836fb99bda066a73');
const table='edu_preschool_pickup_handover_events',version='20260927030000';
const resultPath=path.join(__dirname,'HANDOVER_APPLY_RESULT.json');if(fs.existsSync(resultPath))throw Error('RECONCILE_EXISTING_RESULT_BEFORE_RETRY');
const save=(name,value)=>fs.writeFileSync(path.join(__dirname,name),JSON.stringify(value,null,2),{flag:'wx'});
save('APPROVAL.json',{at:new Date().toISOString(),authority:'User: aprrove lam tiep; tiep tuc hoan thanh cac phan con thieu',scope:'../HANDOVER_PREREQUISITE_SCOPE.md',file,sha256,target:config.target,production:false,delivery:false});
const db=new Client({connectionString:config.dbUrl,ssl:{rejectUnauthorized:false},connectionTimeoutMillis:15000});
async function state(){const queries={
history:'SELECT version,name,md5(statements::text) AS statements_md5 FROM supabase_migrations.schema_migrations ORDER BY version',
tables:"SELECT c.relname AS name,c.relrowsecurity,c.relforcerowsecurity,c.relacl::text AS acl FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY 1",
policies:"SELECT tablename,policyname,roles,cmd,qual,with_check FROM pg_policies WHERE schemaname='public' ORDER BY 1,2",
functions:"SELECT p.proname AS name,pg_get_function_identity_arguments(p.oid) AS args,p.proacl::text AS acl,md5(pg_get_functiondef(p.oid)) AS definition_md5 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.prokind='f' ORDER BY 1,2",
defaults:'SELECT defaclrole::regrole::text AS owner,defaclnamespace::regnamespace::text AS schema,defaclobjtype,defaclacl::text FROM pg_default_acl ORDER BY 1,2,3',
indexes:"SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' ORDER BY 1,2"};const result={};for(const[k,q]of Object.entries(queries))result[k]=(await db.query(q)).rows;return result;}
async function data(tables){const out=[];for(const{name}of tables){const q='"'+name.replaceAll('"','""')+'"';out.push({name,...(await db.query(`SELECT count(*)::text AS count,md5(coalesce(string_agg(h,'' ORDER BY h),'')) AS digest FROM (SELECT md5(to_jsonb(t)::text) AS h FROM public.${q} t) x`)).rows[0]});}return out;}
(async()=>{let committed=false,before;try{await db.connect();await db.query('BEGIN ISOLATION LEVEL REPEATABLE READ');await db.query("SET LOCAL lock_timeout='5s'");await db.query("SET LOCAL statement_timeout='45s'");await db.query("SELECT pg_advisory_xact_lock(hashtextextended('bella:preschool:e2e-approved-chain-bundle:20261023',0))");
assert.equal((await db.query('SELECT to_regclass($1) AS obj',['public.'+table])).rows[0].obj,null);assert.equal((await db.query('SELECT version FROM supabase_migrations.schema_migrations WHERE version=$1',[version])).rowCount,0);
before=await state();before.data=await data(before.tables);before.at=(await db.query('SELECT clock_timestamp() AS at')).rows[0].at;save('HANDOVER_BEFORE.json',before);
await db.query(sql);await db.query('REVOKE TRUNCATE ON public.edu_preschool_pickup_handover_events FROM anon,authenticated');
await db.query('INSERT INTO supabase_migrations.schema_migrations(version,name,statements) VALUES($1,$2,$3::text[])',[version,'preschool_safe_pickup_handover_events',[sql]]);
const acl=(await db.query("SELECT r AS role,has_table_privilege(r,'public.edu_preschool_pickup_handover_events','TRUNCATE') AS truncate FROM unnest(ARRAY['anon','authenticated']) r")).rows;assert.ok(acl.every(r=>r.truncate===false));
const after=await state();after.data=await data(before.tables);assert.deepEqual(after.data,before.data);assert.deepEqual(after.defaults,before.defaults);assert.deepEqual(after.functions,before.functions);
assert.deepEqual(after.tables.filter(t=>t.name!==table),before.tables);assert.deepEqual(after.policies.filter(t=>t.tablename!==table),before.policies);assert.deepEqual(after.indexes.filter(t=>t.tablename!==table),before.indexes);assert.deepEqual(after.history.filter(h=>h.version!==version),before.history);
assert.equal(after.history.length,before.history.length+1);assert.equal(after.indexes.filter(t=>t.tablename===table).length,4);assert.equal(after.tables.find(t=>t.name===table).relrowsecurity,true);
await db.query("NOTIFY pgrst,'reload schema'");await db.query('COMMIT');committed=true;save('HANDOVER_AFTER.json',{...after,acl});
const ledger=(await db.query('SELECT version FROM supabase_migrations.schema_migrations WHERE version=$1',[version])).rows;assert.equal(ledger.length,1);
const result={at:new Date().toISOString(),target:config.target,result:'PASS_SCOPED',file,sha256,committed,existingTablesPreserved:before.data.length,existingRowsPreserved:before.data.reduce((n,r)=>n+Number(r.count),0),preservedHistoryEntries:before.history.length,newIndexesIncludingPrimaryKey:4,truncateDenied:2,snapshot:'REPEATABLE READ: own changes visible; concurrent external writes are outside this transaction proof',fullChainGoLive:'NOT_PROVEN'};save('HANDOVER_APPLY_RESULT.json',result);console.log(JSON.stringify(result));
}catch(e){if(!committed)await db.query('ROLLBACK').catch(()=>{});const result={at:new Date().toISOString(),result:committed?'POST_COMMIT_VERIFICATION_FAILED':'FAIL_ROLLED_BACK',committed,code:e.code??null,error:String(e.message).slice(0,600)};if(before&&!committed)result.rollbackMetadataUnchanged=JSON.stringify(await state())===JSON.stringify(Object.fromEntries(Object.entries(before).filter(([k])=>k!=='data'&&k!=='at')));save('HANDOVER_APPLY_RESULT.json',result);console.error(JSON.stringify(result));process.exitCode=1;}finally{await db.end();}})();
