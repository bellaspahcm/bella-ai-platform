const fs=require('node:fs'),path=require('node:path'),{Client}=require('pg'),cfg=require('../target-env.cjs');
const packet=path.dirname(__dirname),baseline=JSON.parse(fs.readFileSync(path.join(packet,'TARGET_AFTER.json'))),metadata=JSON.parse(fs.readFileSync(path.join(__dirname,'HANDOVER_AFTER.json')));
const cutoff='2026-10-23T02:21:16.796Z',quote=n=>'"'+n.replaceAll('"','""')+'"';
const tenantIds=new Set();for(const name of fs.readdirSync(packet).filter(n=>n.startsWith('http-'))){const f=path.join(packet,name,'FIXTURE_IDS.json');if(fs.existsSync(f)){const fixture=JSON.parse(fs.readFileSync(f));tenantIds.add(fixture.tenantId);tenantIds.add(fixture.foreignTenantId);}}
(async()=>{const db=new Client({connectionString:cfg.dbUrl,ssl:{rejectUnauthorized:false}});await db.connect();try{
await db.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');await db.query("SET LOCAL statement_timeout='45s'");
const cols=(await db.query("SELECT table_name,column_name,data_type FROM information_schema.columns WHERE table_schema='public'")).rows;
const results=[];for(const before of baseline.data){const has=name=>cols.some(c=>c.table_name===before.name&&c.column_name===name),clauses=[],params=[];
if(before.name==='tenants'){params.push([...tenantIds]);clauses.push(`NOT(t.id::text=ANY($${params.length}::text[]))`);}
else if(has('tenant_id')){params.push([...tenantIds]);clauses.push(`(NOT(t.tenant_id::text=ANY($${params.length}::text[])) OR t.tenant_id IS NULL)`);}
if(['audit_logs','auto_customer_profiles','customers','tenants','users'].includes(before.name)){
 params.push(cutoff);clauses.push(`t.created_at <= $${params.length}::timestamptz`);
}
const filter=clauses.length?'WHERE '+clauses.join(' AND '):'';
const row=(await db.query(`SELECT count(*)::text count,md5(coalesce(string_agg(h,'' ORDER BY h),'')) digest FROM (SELECT md5(to_jsonb(t)::text) h FROM public.${quote(before.name)} t ${filter}) q`,params)).rows[0];
results.push({table:before.name,count:row.count,baselineCount:before.count,originalMultisetMatches:row.count===before.count&&row.digest===before.digest,filter:filter||'ALL_ROWS'});
}
const queries={
 history:'SELECT version,name,md5(statements::text) AS statements_md5 FROM supabase_migrations.schema_migrations ORDER BY version',
 tables:"SELECT c.relname AS name,c.relrowsecurity,c.relforcerowsecurity,c.relacl::text AS acl FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY 1",
 policies:"SELECT tablename,policyname,roles,cmd,qual,with_check FROM pg_policies WHERE schemaname='public' ORDER BY 1,2",
 functions:"SELECT p.proname AS name,pg_get_function_identity_arguments(p.oid) AS args,p.proacl::text AS acl,md5(pg_get_functiondef(p.oid)) AS definition_md5 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.prokind='f' ORDER BY 1,2",
 defaults:'SELECT defaclrole::regrole::text AS owner,defaclnamespace::regnamespace::text AS schema,defaclobjtype,defaclacl::text FROM pg_default_acl ORDER BY 1,2,3',
};const metadataResults={};for(const [key,sql]of Object.entries(queries)){const rows=(await db.query(sql)).rows;metadataResults[key]={unchanged:JSON.stringify(rows)===JSON.stringify(metadata[key]),actualRows:rows.length,baselineRows:metadata[key].length};}
await db.query('COMMIT');const output={at:new Date().toISOString(),target:cfg.target,mode:'READ_ONLY',originalTables:results.length,matched:results.filter(r=>r.originalMultisetMatches).length,cutoffForFivePreviouslyReconciledTables:cutoff,runOwnedTenantsExcluded:tenantIds.size,
 results,metadataResults,note:'Raw shared-target aggregate drift packet remains historical FAIL. This proves only original row multisets with explicit run-owned exclusion and cutoff reconciliation, plus current metadata equality; it does not attribute external additions.'};
fs.writeFileSync(path.join(__dirname,'FINAL_ORIGINAL_DATA_READBACK.json'),JSON.stringify(output,null,2),{flag:'wx'});console.log(JSON.stringify({...output,results:results.filter(r=>!r.originalMultisetMatches)}));
}finally{await db.end();}})().catch(e=>{console.error(JSON.stringify({code:e.code??null,message:e.message}));process.exitCode=1;});
