const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const h=require('../run-target-http.cjs'),{signInFixture}=require('../run-finance-resume.cjs');
const out=[];let browser;
(async()=>{let phase='preflight';try{
await h.db.connect();const accountant=await signInFixture('accountant'),owner=await signInFixture('admin');
const operations=await h.rows('edu_fin_reconciliation_operations');assert.equal(operations.length,2);
const operation=operations.find(row=>Number(row.request_payload.paymentAmount)===100000);assert.ok(operation);
const request=operation.request_payload;assert.equal(request.kind,'new-payment');
const intent={version:1,actorId:accountant.id,tenantId:h.fixtures.tenantId,branchId:h.fixtures.branchId,
 invoiceId:operation.invoice_id,operationKey:operation.operation_key,paymentAmount:Number(request.paymentAmount),paymentMethod:request.paymentMethod};
const key=['preschool-finance-payment-v1',intent.actorId,intent.tenantId,intent.branchId,intent.invoiceId].join(':');
const financialBefore=JSON.stringify(await h.financialState()),admissionBefore=JSON.stringify(await h.rows('edu_enrollments'));
h.prepareRuntime();await h.startServer();
phase='same_source_admission_http_recovery';const admission=(await h.rows('preschool_admission_operations'))[0];
const recovered=await h.http(owner,'/api/education/enrollments',{operationKey:admission.operation_key});h.expectStatus(recovered,201,'admission recovery');
assert.equal(recovered.data.enrollment.id,JSON.parse(admissionBefore)[0].id);assert.equal(JSON.stringify(await h.rows('edu_enrollments')),admissionBefore);
out.push({name:phase,result:'PASS',canonicalIdUnchanged:true,noEnrollmentCreated:true});
phase='same_source_payment_browser_recovery';const {chromium}=require('playwright'),{expect}=require('@playwright/test');browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:1100}});
await context.addCookies(Array.from(accountant.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));
await context.addInitScript(({key,intent})=>{if(!localStorage.getItem(key))localStorage.setItem(key,JSON.stringify(intent));},{key,intent});
const page=await context.newPage(),errors=[],sent=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.url().endsWith('/api/education/finance')&&r.method()==='POST'){const p=r.postDataJSON();if(p.action==='recordAndReconcilePayment')sent.push(p);}});
const canonicalContext=await h.http(accountant,'/api/tenant/context');h.expectStatus(canonicalContext,200,'tenant context');assert.equal(canonicalContext.data.tenantId,h.fixtures.tenantId);
// Warm the real read path before the browser's fixed tenant-context timeout.
h.expectStatus(await h.http(accountant,'/api/education/finance?branchId='+h.fixtures.branchId),200,'finance read');
await page.goto(h.origin+'/dashboard/education/finance?tab=invoices',{waitUntil:'domcontentloaded',timeout:120000});
const branch=page.getByRole('combobox',{name:'Cơ sở tài chính'});await expect(branch).toBeEnabled({timeout:90000});await branch.click();await page.getByRole('listbox').getByRole('button',{name:'Controlled Chain branch A',exact:true}).click();
await expect(page.getByTitle('Thu học phí',{exact:true}).first()).toBeVisible({timeout:90000});await page.getByTitle('Thu học phí',{exact:true}).first().click();
await expect(page.getByRole('spinbutton',{name:'Số tiền thanh toán'})).toBeDisabled();await expect(page.getByRole('spinbutton',{name:'Số tiền thanh toán'})).toHaveValue('100000');
await page.getByTestId('finance-confirm-payment').click();await expect(page.getByText(/Biên nhận:/)).toBeVisible({timeout:60000});assert.equal(sent.length,1);assert.equal(sent[0].operationKey,intent.operationKey);
const saved=await page.evaluate(key=>JSON.parse(localStorage.getItem(key)),key);assert.equal(saved.result.paymentId,operation.payment_id);assert.equal(saved.result.receiptId,operation.receipt_id);
assert.equal(JSON.stringify(await h.financialState()),financialBefore);assert.deepEqual(errors,[]);
await page.screenshot({path:path.join(h.directory,'FINAL_PAYMENT_RECOVERED.png'),fullPage:true});
out.push({name:phase,result:'PASS',operationKey:intent.operationKey,canonicalPaymentId:operation.payment_id,canonicalReceiptId:operation.receipt_id,exactRequestRetained:true,financeRowsUnchanged:true,pageErrors:errors});
await context.close();await browser.close();browser=undefined;
}catch(e){out.push({name:phase,result:'FAIL',error:String(e.message).replace(/eyJ[A-Za-z0-9._-]{30,}/g,'[REDACTED]').slice(0,1500)});process.exitCode=1;}
finally{if(browser)await browser.close();await h.stopServer();await h.db.end();const result={at:new Date().toISOString(),target:h.config.target,source:h.fingerprint(),runtimePacket:h.directory,observations:out};
fs.writeFileSync(path.join(h.directory,'FINAL_RECOVERY_EVIDENCE.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({packet:h.directory,observations:out}));}})();
