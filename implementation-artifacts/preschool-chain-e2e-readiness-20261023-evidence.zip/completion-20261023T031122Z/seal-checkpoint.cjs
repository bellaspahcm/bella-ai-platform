const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'../../..'),packet=path.dirname(__dirname),sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const sourcePaths=[...new Set((git(['diff','HEAD','--name-only','--','src','tests','supabase/migrations'])+'\n'+git(['ls-files','-o','--exclude-standard','src','tests','supabase/migrations'])).split(/\r?\n/).filter(Boolean))].sort();
const files=sourcePaths.map(file=>({file,sha256:sha(fs.readFileSync(path.join(root,file)))}));
const source={at:new Date().toISOString(),head:git(['rev-parse','HEAD']),branch:git(['branch','--show-current']),dirty:true,files,manifestSha256:sha(JSON.stringify(files))};
const latest=[];for(const folder of fs.readdirSync(packet).filter(n=>n.startsWith('http-'))){for(const name of ['FINAL_RECOVERY_EVIDENCE.json','HANDOVER_RESUME_EVIDENCE.json']){const file=path.join(packet,folder,name);if(fs.existsSync(file))latest.push({file:path.relative(__dirname,file).replaceAll('\\','/'),...JSON.parse(fs.readFileSync(file))});}}
const attendanceFile='attendance-2026-10-23T03-44-39-465Z/ATTENDANCE_EVIDENCE.json',attendance=JSON.parse(fs.readFileSync(path.join(__dirname,attendanceFile)));
const binding=[{file:attendanceFile,...attendance},...latest].map(r=>({file:r.file,sourceMatchesFinal:r.source.manifestSha256===source.manifestSha256,passed:r.observations.filter(o=>o.result==='PASS').length,failed:r.observations.filter(o=>o.result==='FAIL').length}));
const original=JSON.parse(fs.readFileSync(path.join(packet,'EVIDENCE_HASHES.json'))).files;
const oldMismatches=original.filter(r=>!fs.existsSync(path.join(packet,r.file))||sha(fs.readFileSync(path.join(packet,r.file)))!==r.sha256).map(r=>r.file);
const security=JSON.parse(fs.readFileSync(path.join(__dirname,'SECURITY_RECOVERY_EVIDENCE.json')));
const securityPaths=security.source.files.filter(r=>/^(supabase\/migrations\/|src\/platform\/education\/contracts\/|src\/products\/bella-education\/services\/|src\/platform\/org-unit\/)/.test(r.file));
const securityReuse={sameRelevantFileHashes:securityPaths.every(r=>files.find(f=>f.file===r.file)?.sha256===r.sha256),filesCompared:securityPaths.length,note:'Prior event/lock-wait execution retained; endpoint/UI changes do not alter these relevant implementations. This is not a rerun.'};
const scan=[];function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())walk(file);else if(/\.(json|md|log|cjs|patch)$/.test(entry.name)){const text=fs.readFileSync(file,'utf8');const hit=/\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}|base64-eyJ[A-Za-z0-9_-]{80,}|sb_secret_[A-Za-z0-9_-]{25,}|postgres(?:ql)?:\/\/[^\s'"<>]+:[^\s'"<>]+@/g.test(text);if(hit)scan.push(path.relative(packet,file).replaceAll('\\','/'));}}}
walk(packet);
const result={at:new Date().toISOString(),source:source.manifestSha256,sourceFiles:files.length,executedSourceBindings:binding,priorSecurityEvidenceReuse:securityReuse,
 baselineEvidenceFiles:original.length,baselineEvidenceHashMismatches:oldMismatches,credentialPatternScan:{patternsOnlyNotCompleteSecretAttestation:true,filesWithPossibleMaterial:scan},
 independentReview:{acceptance:'PASS_NO_ACTIONABLE_FINDINGS',blind:'FAILED_SERVICE_USAGE_LIMIT',edge:'FAILED_SERVICE_USAGE_LIMIT',overall:'PARTIAL_NOT_SEALED'},
 requiredRemoteChecks:['Frozen File Check','Architecture Guard Verification','Dependency Boundary Check','Logistics Kernel Regression'],remoteChecks:'NOT_PROVEN',
 fullMigrationParity:'NOT_PROVEN:21 scoped migrations match approved executable history;419 historical pending migrations not reconciled',
 delivery:'HOLD',fullChainGoLive:'NOT_PROVEN',deliveryPerformed:false};
fs.writeFileSync(path.join(__dirname,'FINAL_SOURCE_BOUND.json'),JSON.stringify(source,null,2),{flag:'wx'});
fs.writeFileSync(path.join(__dirname,'CHECKPOINT.json'),JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify(result));
