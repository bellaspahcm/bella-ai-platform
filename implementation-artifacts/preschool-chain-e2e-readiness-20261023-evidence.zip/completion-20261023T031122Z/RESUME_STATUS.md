# Preschool Chain — checkpoint tiếp tục

Date: 2026-10-23. Target Non-Production: `bmnbqbcdbuklhopfbopv`. Worktree: `C:/Users/DELL/.codex/worktrees/preschool-chain-main-integration/BELLA SPA ERP`. Branch: `codex/preschool-chain-main-integration-20261023`. HEAD: `80e13ea92ee70742d26cd890a45aaa94d8fc7494`; **HEAD alone is not the tested source**. Exact 106-file candidate manifest: `FINAL_SOURCE_BOUND.json`, SHA256 `7b72cc814db67f9d5cc853fcbe643041579a8aff6600da27ec4e968fe94d3551`.

## Đã thực hiện và chứng minh

- Thêm endpoint riêng `/api/education/attendance/courses`; UI Attendance dùng course ID/title canonical, assignment và explicit branch relationship hiện có. Không sửa general courses/detail, bảng `courses`, Kernel, shared schema, grants hay policy. Metadata sức chứa/khối tuổi chưa có contract được hiển thị chưa có dữ liệu. Roster thật rỗng vẫn là 0, không fallback sang sĩ số cũ.
- Actor profile trả thêm đúng `status: active` đã được Platform xác minh, để request-context không từ chối actor hợp lệ. Giữ whitelist field, Auth subject và tenant checks.
- Endpoint unit **14 PASS**, UI **25 PASS** (24 trước sửa test cuối, 25 trong `ATTENDANCE_UI_FINAL_JEST.json`); actor/courses/user regression **85 PASS**. Không cộng các lượt overlap thành tổng mới. TypeScript full/strict, ESLint các file thay đổi, diff checks đều **PASS**. Education architecture **ALLOW, 248/248 bounded baseline**; không tuyên bố zero architecture debt. Logistics local **15 suites / 547 tests PASS**.
- HTTP/browser Attendance trên source cuối: **7 named cases PASS, 0 FAIL**, packet `attendance-2026-10-23T03-44-39-465Z/ATTENDANCE_EVIDENCE.json`. Bao gồm course discovery canonical, anonymous/role/foreign tenant/ungranted branch denial; direct RPC denied; real commit rồi mất response → read-back không ghi thêm event; branch bị thu hồi khi command chờ write lock → 403 và dữ liệu attendance/handover không đổi; browser không còn roster/nút thao tác; registry read canonical.
- Admission HTTP recovery và Finance browser recovery trên source cuối **2 PASS**, `../http-2026-10-23T03-55-48-514Z/FINAL_RECOVERY_EVIDENCE.json`. Cùng operation key, đúng enrollment/payment/receipt IDs, không thêm enrollment hoặc payment. Bằng chứng lost-response/restart trước đó được giữ nguyên; không chạy lại các payment/admission tạo mới đã PASS.
- Bàn giao: lượt browser mới commit nhưng runner lỗi selector `alert`; **giữ FAIL**, không gọi đó là PASS. Recovery riêng dùng đúng QA actor/record đã có: **2 PASS**, `../http-2026-10-23T04-06-01-044Z/HANDOVER_RESUME_EVIDENCE.json`. Một event handover, sequential retry trả cùng ID, browser reload đọc lại và nút đã bàn giao bị khóa, không thêm bản ghi/đổi Finance. Concurrent handover và revocation-during-handover-write vẫn **NOT_PROVEN**.
- Durable enrollment event read/replay: prior actual-DB recovery **PASS_SCOPED**, canonical conflict/direct-client denial và actual role-revocation lock wait được giữ trong `SECURITY_RECOVERY_EVIDENCE.json`. 29 relevant implementation/migration hashes vẫn khớp source cuối. Không có consumer vận hành được phê duyệt; downstream business processing **NOT_PROVEN**.
- Áp đúng một handover prerequisite đã được owner duyệt, không sửa canonical SQL. `HANDOVER_APPLY_RESULT.json`: 268 bảng/275809 dòng cũ giữ nguyên trong transaction; history từ153→154; thu hồi đúng2 TRUNCATE trên bảng mới. `FINAL_TARGET_READBACK_V2.json`: cả21 migration có source hash và SQL thực thi trong history khớp;12 file bỏ wrapper BEGIN/COMMIT theo approved bundle runner, không sửa history. Đây là **scoped parity**, không phải toàn schema parity.
- `FINAL_ORIGINAL_DATA_READBACK.json`: 242/242 original table multisets khớp bằng hash/count; exclude run-owned tenant fixtures và cutoff cụ thể cho5 bảng đã được reconcile trước. History154, tables269, policies420, functions386, defaults21 khớp checkpoint sau apply. Không quy kết các dòng mới của tenant khác; raw aggregate-drift FAIL cũ vẫn giữ. `BASELINE_EVIDENCE_HASH_READBACK.json`: 87/87 file packet cũ không đổi.
- `CHECKPOINT.json`: Attendance, final recovery và handover resume đều khớp cùng exact final source manifest. Credential-pattern scan packet không có hit; không phải chứng nhận tuyệt đối không có secret.

## Fixture và runner cần giữ rõ

- Giữ fixture enrollment/student/payment cũ. Hiện có1 enrollment,1 durable event,2 payments/receipts và1 handover event trong tenant proof; không reset hay cleanup business history.
- Teacher fixture gốc bị thu hồi đúng branch relationship trong negative test; không tự tái tạo để làm test xanh.
- Owner fixture gốc được global sign-out và đặt inactive sau unhandled Playwright diagnostic có thể kèm session cookie. `FAILED_HANDOVER_FIXTURE_SESSION_CLOSED.json` ghi exact ID và thời điểm sớm nhất được review reactivation; **không tự kích hoạt lại**. Không có credential trong packet. QA handover dùng một Auth-backed `admin_staff` fixture riêng, exact IDs trong `../http-2026-10-23T04-03-25-554Z/HANDOVER_FIXTURE.json`.
- Hai thư mục `.next` tạm của worktree integration/original đã được chuyển nguyên sang `D:/Antigravity/.codex-proof/preschool-integration-preserved-next-20261023T034300Z` và `preschool-preserved-next-20261023T034100Z`, giữ junction tại vị trí cũ để xử lý ổ C đầy. Không xóa source/evidence hoặc đổi DB volume. Một manifest ghi dở do ENOSPC được giữ dưới tên `.incomplete.json`; helper cũ được khôi phục đúng hash đã seal (`INTERRUPTED_MANIFEST_PRESERVATION.json`).
- Next proof server đã dừng sau verification. Không lưu token/password/.env, không Production, không stage/commit/push/PR/merge/deploy.

## Gate còn mở — không mở thêm audit tổng thể

1. **Independent review PARTIAL**: Acceptance không finding; Blind/Edge lỗi service usage limit. `REVIEW_RESULT.md` ghi đúng trạng thái; chưa seal independent review toàn candidate.
2. **4 remote required checks NOT_PROVEN**: Frozen File Check, Architecture Guard Verification, Dependency Boundary Check, Logistics Kernel Regression — lấy từ active ruleset21221290. Local frozen/dependency CLI bỏ qua dirty diff nên không thay thế remote evidence; actual dirty-path inventory không đổi Logistics/Healthcare/Finance Kernel hoặc guard/workflow. Commit/push/PR vẫn chưa được phép. GitHub CI/preview effects cần authority riêng trước khi delivery.
3. **Full target migration parity NOT_PROVEN**:21 migration scoped khớp;419 historical pending chưa reconcile. Không áp hàng loạt, không dùng migration mở đầu DROP CASCADE của general courses để làm xanh.
4. **Giới hạn nghiệp vụ/tích hợp**: general course/detail schema collision chưa sửa theo owner boundary; English Center target caller proof chưa đầy đủ; event downstream chưa có approved consumer; handover concurrency/authorization race chưa được chứng minh. Không nới contract/schema/grants hoặc tự thêm consumer để đóng các gate này.
5. Release/rollback operational acceptance trên môi trường đích cuối và owner Go-Live decision vẫn chưa có. Finance allocation ledger không phải GL/double-entry posting; không mở rộng accounting rules.

`ATTENDANCE_UI_API_DB = PASS_SCOPED_FOR_EXECUTED_CASES`  
`CANONICAL_RECOVERY_FINAL_SOURCE = PASS_SCOPED_FOR_EXECUTED_CASES`  
`INDEPENDENT_REVIEW = PARTIAL_NOT_SEALED`  
`DELIVERY = HOLD`  
`FULL_CHAIN_GO_LIVE = NOT_PROVEN`

Bước tiếp: hoàn tất đúng2 review layer bị lỗi và quyết định authority cho commit/push/draft PR + CI/preview Non-Production. Không chạy lại9 business cases/P71/P72 nếu source/dependency tương ứng không đổi; không sửa Healthcare, Kernel, migration history hoặc volume.
