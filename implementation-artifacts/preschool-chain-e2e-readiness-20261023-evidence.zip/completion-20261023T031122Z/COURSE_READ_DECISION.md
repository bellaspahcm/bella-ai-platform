# Attendance course discovery — exact owner decision

Evidence: real signed-in `GET /api/education/courses` returns HTTP 500, `column courses.course_id does not exist`. Read-only `COURSE_PROJECTION_SCHEMA.json` confirms target `courses` has `id`, `module_key`, `title` and commercial training columns; it lacks the Education projection's `course_id`, `course_code`, `course_name`, `metadata`, `duration_weeks`. This is a conflicting schema contract, not a fixture failure.

Do not apply `20260810231500_create_courses_and_enrollments.sql`: its opening statements DROP `courses` and `enrollments` CASCADE. Do not modify the shared table or guess ID mapping.

Recommended minimal Product decision: Attendance classroom discovery consumes canonical `edu_courses` IDs/titles and assignment/current-actor access. Provide a narrow Attendance read endpoint and wire the page to it; retain canonical enrollment/daily-state counts and nullable capacity. Missing age group, room or teacher data is displayed as unknown/unassigned evidence, never fabricated or inferred from a class label. Do not touch the general courses read/detail contract, shared schema, grants, Kernel or old table. Existing role/branch/tenant checks remain mandatory. Test signed-in permitted class discovery, wrong tenant/branch denial, errors fail closed, real browser and post-write read-back.

Alternative: keep Attendance browser held pending owner reconciliation of the shared legacy course projection. No destructive migration is authorized.

## Approved and implemented

Human decision in this conversation: **Duyệt endpoint canonical cho Attendance**.
Change map: Attendance page → `/api/education/attendance/courses` → existing active actor/Auth context and Platform relationship projection → Product assignment/access services → existing canonical course adapter and public Attendance contract. Product/UI owns discovery; Education owns roster truth; Platform owns identity and branch relationships.

Exact Attendance scope: new `src/app/api/education/attendance/courses/route.ts` and its `__tests__/route.test.ts`; update `src/app/dashboard/education/attendance/page.tsx` and its test. No new SQL or shared contract. Existing adapter is reused without modification. The current-actor active-status repair remains under the previously approved actor-profile contract scope; it exposes the already-validated `active` state, not a new permission.

Acceptance: real Auth before operation-client creation; only existing admin/super_admin/admin_staff Attendance actions; trusted tenant; explicit relationship provenance rather than tenant-admin inference; current course/enrollment branch checks; exact canonical IDs; actual attendance counts; unknown capacity/age metadata; private no-store responses; DB/permission failures fail closed. General courses/detail, legacy tables, Kernel, policies/grants and schema are outside this endpoint change.

Verification: route unit tests; UI ordering/uncertain-response regressions; real signed-in HTTP plus anonymous/role/tenant/branch denials; actual browser write → lost response → read-back without a second write; revocation while waiting for the DB lock and persisted-data equality; final source/runtime hash reconciliation. This is a Non-Production proof, not delivery authority.
