const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {Client}=require('pg'),cfg=require('../target-env.cjs');
const root=path.resolve(__dirname,'../../..'),packet=path.dirname(__dirname);
const fixtures=JSON.parse(fs.readFileSync(path.join(packet,'http-2026-10-23T02-38-27-046Z/FIXTURE_IDS.json')));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{const db=new Client({connectionString:cfg.dbUrl,ssl:{rejectUnauthorized:false}});await db.connect();try{
await db.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
const acl=(await db.query(`SELECT c.relname,c.relacl::text,
 has_table_privilege('anon',c.oid,'SELECT') anon_select,
 has_table_privilege('authenticated',c.oid,'SELECT') authenticated_select,
 has_table_privilege('authenticated',c.oid,'INSERT') authenticated_insert,
 has_table_privilege('authenticated',c.oid,'UPDATE') authenticated_update,
 has_table_privilege('authenticated',c.oid,'DELETE') authenticated_delete
 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE n.nspname='public' AND c.relname=ANY($1::text[]) ORDER BY c.relname`,[
 ['edu_attendance','edu_attendance_daily_state','edu_preschool_pickup_handover_events'],
])).rows;
const plan=JSON.parse(fs.readFileSync(path.join(packet,'TARGET_APPLY_PLAN.json'))).manifest;
const expected=[...plan,{version:'20260927030000',file:'20260927030000_preschool_safe_pickup_handover_events.sql',sha256:'17d5ca4cf8b5265fb36e4e93f4c86ca5254701a1745d039c836fb99bda066a73'}];
const versions=(await db.query('SELECT version,statements FROM supabase_migrations.schema_migrations WHERE version=ANY($1::text[])',[expected.map(r=>r.version)])).rows;
const migrationReadback=expected.map(m=>{const row=versions.find(r=>r.version===m.version),source=fs.readFileSync(path.join(root,'supabase/migrations',m.file),'utf8');
 const executable=m.version==='20260927030000'?source:source.replace(/^\s*BEGIN;\s*$/gm,'').replace(/^\s*COMMIT;\s*$/gm,'');
 return {
 version:m.version,file:m.file,sourceHashMatches:hash(source)===m.sha256,historyExists:!!row,
 historyStatementsMatchSource:!!row&&Array.isArray(row.statements)&&row.statements.join('\n')===source,
 historyMatchesApprovedExecutable:!!row&&Array.isArray(row.statements)&&row.statements.join('\n')===executable,
 executableTransform:m.version==='20260927030000'?'NONE':'Outer transaction wrappers removed by approved apply-approved-target.cjs; the bundle used one encompassing transaction',
};});
const counts={};for(const table of ['preschool_admission_operations','edu_enrollments','edu_enrollment_event_records','edu_enrollment_event_replays','edu_attendance','edu_attendance_daily_state','edu_preschool_pickup_handover_events','edu_fin_payments','edu_fin_receipts']){
 if(table==='edu_enrollment_event_replays'){
  counts[table]=Number((await db.query('SELECT count(*) n FROM public.edu_enrollment_event_replays r JOIN public.edu_enrollment_event_records e USING(event_id) WHERE e.tenant_id=$1',[fixtures.tenantId])).rows[0].n);continue;
 }
 if(!(await db.query('SELECT to_regclass($1) present',['public.'+table])).rows[0].present){counts[table]='ABSENT';continue;}
 counts[table]=Number((await db.query(`SELECT count(*) n FROM public.${table} WHERE tenant_id=$1`,[fixtures.tenantId])).rows[0].n);
}
const actors=(await db.query(`SELECT u.id,u.role,u.status,count(r.id)::int explicit_branch_relationships
 FROM public.users u LEFT JOIN public.people_directory p ON p.user_id=u.id AND p.tenant_id=u.tenant_id
 LEFT JOIN public.org_relationships r ON r.from_id=p.id AND r.tenant_id=u.tenant_id AND r.id=ANY($2::uuid[])
 WHERE u.id=ANY($1::uuid[]) GROUP BY u.id,u.role,u.status ORDER BY u.id`,[
 fixtures.actors.map(a=>a.id),fixtures.actors.map(a=>a.relationshipId).filter(Boolean),
])).rows;
await db.query('COMMIT');const result={at:new Date().toISOString(),target:cfg.target,mode:'READ_ONLY',acl,migrationReadback,counts,actors,
 note:'admin_staff relationship was intentionally revoked by the recorded lock-wait test; do not recreate it as a production data repair.'};
fs.writeFileSync(path.join(__dirname,'FINAL_TARGET_READBACK_V2.json'),JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify({acl,migrations: migrationReadback.length,sourceAndExecutableHistoryMatches:migrationReadback.filter(r=>r.sourceHashMatches&&r.historyMatchesApprovedExecutable).length,counts,actorFixtureRows:actors.length}));
}finally{await db.end();}})().catch(e=>{console.error(JSON.stringify({code:e.code??null,error:e.message}));process.exitCode=1;});
