const fs=require('node:fs'),path=require('node:path');
const h=require('../run-target-http.cjs'),{signInFixture}=require('../run-finance-resume.cjs');
(async()=>{try{await h.db.connect();const owner=await signInFixture('admin');
const logout=await owner.signed.auth.signOut({scope:'global'});if(logout.error)throw new Error('TEST_SESSION_LOGOUT_FAILED');
const changed=await h.db.query("UPDATE public.users SET status='inactive' WHERE id=$1 AND tenant_id=$2 AND role='admin' AND status='active' RETURNING id",[owner.id,h.fixtures.tenantId]);
const handovers=await h.rows('edu_preschool_pickup_handover_events');
const result={at:new Date().toISOString(),target:h.config.target,fixtureActorId:owner.id,globalRefreshSessionsRevoked:true,fixtureProfileInactive:changed.rowCount===1,
 handoverRows:handovers.length,handoverIds:handovers.map(r=>r.id),reason:'Unhandled Playwright route diagnostic could include a run-owned test-session cookie. No credentials copied into this packet. Inactive profile fails closed at Platform/Product auth. Preserve the test actor; do not reactivate until the old access-token lifetime has elapsed or an approved immediate invalidation is verified.',
 earliestReactivationReviewAt:new Date(Date.now()+65*60000).toISOString(),financialCounts:{payments:(await h.rows('edu_fin_payments')).length,receipts:(await h.rows('edu_fin_receipts')).length}};
fs.writeFileSync(path.join(__dirname,'FAILED_HANDOVER_FIXTURE_SESSION_CLOSED.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({fixtureProfileInactive:result.fixtureProfileInactive,refreshSessionsRevoked:true,handoverRows:handovers.length}));
}finally{await h.db.end();}})().catch(e=>{console.error('SESSION_CLEANUP_NOT_PROVEN');process.exitCode=1;});
