const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const h=require('../run-target-http.cjs'),{signInFixture}=require('../run-finance-resume.cjs');let browser;const observations=[];
const {randomUUID}=require('node:crypto'),{createServerClient}=require('@supabase/ssr');
let routeTask;
async function handoverFixture(){
 const idParts={personId:randomUUID(),relationshipId:randomUUID()},email='preschool-chain-'+randomUUID()+'@example.test',password=randomUUID()+randomUUID();
 const auth=await h.admin.auth.admin.createUser({email,password,email_confirm:true});if(auth.error||!auth.data.user)throw new Error('HANDOVER_AUTH_FIXTURE_CREATE_FAILED');
 const id=auth.data.user.id;await h.db.query('BEGIN');try{
 await h.db.query("INSERT INTO public.users(id,tenant_id,email,full_name,role,status) VALUES($1,$2,$3,'Controlled handover QA actor','admin_staff','active')",[id,h.fixtures.tenantId,email]);
 await h.db.query("INSERT INTO public.people_directory(id,tenant_id,user_id,person_type,display_name,is_active) VALUES($1,$2,$3,'employee','Controlled handover QA actor',true)",[idParts.personId,h.fixtures.tenantId,id]);
 await h.db.query("INSERT INTO public.org_relationships(id,tenant_id,from_id,from_type,to_id,to_type,rel_type) VALUES($1,$2,$3,'person',$4,'unit','belongs_to')",[idParts.relationshipId,h.fixtures.tenantId,idParts.personId,h.fixtures.branchId]);await h.db.query('COMMIT');
 }catch(e){await h.db.query('ROLLBACK');throw e;}
 const fixture={id,...idParts,tenant:h.fixtures.tenantId,role:'admin_staff',reason:'Separate controlled QA fixture; original owner inactive and original teacher branch intentionally revoked. No original actor/mapping repaired.'};
 fs.writeFileSync(path.join(h.directory,'HANDOVER_FIXTURE.json'),JSON.stringify(fixture,null,2),{flag:'wx'});
 const jar=new Map(),signed=createServerClient(h.config.apiUrl,h.config.anonKey,{cookies:{getAll:()=>Array.from(jar,([name,value])=>({name,value})),setAll:items=>items.forEach(c=>jar.set(c.name,c.value))}});
 const login=await signed.auth.signInWithPassword({email,password});if(login.error||login.data.user?.id!==id)throw new Error('HANDOVER_FIXTURE_AUTH_NOT_VERIFIED');
 return {...fixture,signed,jar,cookie:()=>Array.from(jar,([name,value])=>name+'='+value).join('; ')};
}
(async()=>{let phase='preflight';try{
await h.db.connect();const owner=await handoverFixture(),foreign=await signInFixture('admin',h.fixtures.foreignTenantId),accountant=await signInFixture('accountant'),revokedTeacher=await signInFixture('admin_staff');
const enrollment=(await h.rows('edu_enrollments'))[0],before=await h.rows('edu_preschool_pickup_handover_events');assert.equal(before.length,0);
const beforeFinance=JSON.stringify(await h.financialState());h.prepareRuntime();await h.startServer();
const url='/api/education/attendance?courseId='+enrollment.course_id+'&date=2026-10-23',roster=await h.http(owner,url);h.expectStatus(roster,200,'owner roster');const row=roster.data.roster[0],guardian=row.authorizedGuardians[0];assert.ok(guardian);assert.equal(row.safePickupHandover,null);
const body={studentPartyId:row.studentPartyId,guardianPartyId:guardian.guardianPartyId,pickupAuthorizationId:guardian.authorizationId};
phase='handover_permission_negative';for(const [actor,status]of [[null,401],[accountant,403],[foreign,403],[revokedTeacher,403]])h.expectStatus(await h.http(actor,'/api/education/attendance/handover',body),status,'handover rejected');
assert.deepEqual(await h.rows('edu_preschool_pickup_handover_events'),before);observations.push({name:phase,result:'PASS',negativeCases:4,noHandoverWrite:true});
phase='handover_browser_commit_lost_ack';const {chromium}=require('playwright'),{expect}=require('@playwright/test');browser=await chromium.launch({headless:true});const context=await browser.newContext({viewport:{width:1440,height:1100}});
await context.addCookies(Array.from(owner.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));h.expectStatus(await h.http(owner,'/api/tenant/context'),200,'tenant context');
const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));let discarded=false;
await page.goto(h.origin+'/dashboard/education/attendance',{waitUntil:'domcontentloaded',timeout:120000});await expect(page.getByRole('button',{name:'Bàn giao',exact:true})).toBeVisible({timeout:90000});
let resolveRoute;const routeCompleted=new Promise(resolve=>{resolveRoute=resolve;});
await page.route('**/api/education/attendance/handover',route=>{routeTask=(async()=>{if(!discarded&&route.request().method()==='POST'){assert.deepEqual(route.request().postDataJSON(),body);const real=await route.fetch({timeout:60000});assert.equal(real.status(),201);discarded=true;await route.abort('failed');resolveRoute({ok:true});}else await route.continue();})().catch(()=>{resolveRoute({ok:false});});return routeTask;});
await page.getByRole('button',{name:'Bàn giao',exact:true}).click();const intercepted=await Promise.race([routeCompleted,new Promise(resolve=>setTimeout(()=>resolve({ok:false,timeout:true}),65000))]);assert.equal(intercepted.ok,true,'Real handover commit not confirmed');assert.ok(discarded);await expect(page.getByRole('alert')).toBeVisible({timeout:30000});
const committed=await h.rows('edu_preschool_pickup_handover_events');assert.equal(committed.length,1);assert.equal(committed[0].student_party_id,body.studentPartyId);assert.equal(committed[0].guardian_party_id,body.guardianPartyId);assert.equal(committed[0].pickup_authorization_id,body.pickupAuthorizationId);
await page.unroute('**/api/education/attendance/handover');const retry=await h.http(owner,'/api/education/attendance/handover',body);h.expectStatus(retry,201,'same handover retry');assert.equal(retry.data.handover.id,committed[0].id);assert.deepEqual(await h.rows('edu_preschool_pickup_handover_events'),committed);
await page.reload({waitUntil:'domcontentloaded'});await expect(page.getByRole('button',{name:'Đã bàn giao',exact:true})).toBeDisabled({timeout:60000});assert.equal(JSON.stringify(await h.financialState()),beforeFinance);assert.deepEqual(errors,[]);
await page.screenshot({path:path.join(h.directory,'HANDOVER_RECOVERED.png'),fullPage:true});observations.push({name:phase,result:'PASS',canonicalHandoverId:committed[0].id,sameIdentityAfterLostAcknowledgement:true,sequentialRetryNoDuplicate:true,browserReadback:true,financeRowsUnchanged:true,concurrentRetry:'NOT_PROVEN',revocationDuringHandoverWrite:'NOT_PROVEN'});
await context.close();await browser.close();browser=undefined;
}catch(e){observations.push({name:phase,result:'FAIL',error:String(e.message).replace(/eyJ[A-Za-z0-9._-]{30,}/g,'[REDACTED]').slice(0,1300)});process.exitCode=1;}
finally{if(routeTask)await routeTask;if(browser)await browser.close();await h.stopServer();await h.db.end();const result={at:new Date().toISOString(),target:h.config.target,source:h.fingerprint(),runtimePacket:h.directory,observations};fs.writeFileSync(path.join(h.directory,'HANDOVER_EVIDENCE.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({packet:h.directory,observations}));}})();
