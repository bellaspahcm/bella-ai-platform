const fs = require('node:fs');
const path = require('node:path');
const { randomUUID, createHash } = require('node:crypto');
const { spawn, spawnSync, execFileSync } = require('node:child_process');
const assert = require('node:assert/strict');
const { Client } = require('pg');
const { createClient } = require('@supabase/supabase-js');
const { createServerClient } = require('@supabase/ssr');
const config = require('./target-env.cjs');
const root = path.resolve(__dirname, '../..');
const directory = path.join(__dirname, 'http-' + new Date().toISOString().replace(/[:.]/g, '-'));
fs.mkdirSync(directory);
// Reuse the established proof-launcher pattern: source-bound copy beside the
// existing dependency runtime. Preserve the actual worktree and its junction.
const dependencyRoot = fs.realpathSync(path.join(root, 'node_modules'));
let runtime = path.join('D:/Antigravity/.codex-proof', 'chain-e2e-' + path.basename(directory));
let runtimeManifest;
function prepareRuntime() {
  const listed=execFileSync('git',['ls-files','-c','-o','--exclude-standard'],{cwd:root,encoding:'utf8'}).trim().split(/\r?\n/);
  const files=[...new Set(listed)].filter(file=>/^(src\/|public\/|packages\/shared\/)/.test(file)
    || /^(package(-lock)?\.json|tsconfig\.json|next-env\.d\.ts|next\.config\.[cm]?[jt]s|postcss\.config\.[cm]?[jt]s|components\.json)$/.test(file));
  for(const previous of fs.readdirSync(__dirname).filter(n=>n.startsWith('http-')).sort().reverse()) {
    const receipt=path.join(__dirname,previous,'RUNTIME_SOURCE.json');if(!fs.existsSync(receipt))continue;
    const candidate=JSON.parse(fs.readFileSync(receipt));
    if(candidate.dependencyRoot!==dependencyRoot||candidate.manifest.length!==files.length)continue;
    if(!candidate.manifest.every(row=>files.includes(row.file)&&fs.existsSync(path.join(candidate.runtime,row.file))
      &&createHash('sha256').update(fs.readFileSync(path.join(root,row.file))).digest('hex')===row.sourceSha256
      &&createHash('sha256').update(fs.readFileSync(path.join(candidate.runtime,row.file))).digest('hex')===row.sourceSha256))continue;
    runtime=candidate.runtime;runtimeManifest=candidate.manifest;
    fs.writeFileSync(path.join(directory,'RUNTIME_SOURCE.json'),JSON.stringify({...candidate,reusedFrom:previous,allSourceHashesReverified:true},null,2));return;
  }
  fs.mkdirSync(runtime);runtimeManifest=[];
  for(const file of files) {
    const source=path.join(root,file),destination=path.join(runtime,file);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.copyFileSync(source,destination);
    const sourceSha256=createHash('sha256').update(fs.readFileSync(source)).digest('hex');
    const runtimeSha256=createHash('sha256').update(fs.readFileSync(destination)).digest('hex');assert.equal(runtimeSha256,sourceSha256);
    runtimeManifest.push({file,sourceSha256,runtimeSha256});
  }
  fs.symlinkSync(dependencyRoot,path.join(runtime,'node_modules'),'junction');
  fs.writeFileSync(path.join(directory,'RUNTIME_SOURCE.json'),JSON.stringify({runtime,dependencyRoot,manifest:runtimeManifest},null,2));
}
const port = 15440, origin = 'http://127.0.0.1:' + port;
const db = new Client({ connectionString: config.dbUrl, ssl: { rejectUnauthorized: false }, connectionTimeoutMillis: 15000 });
const admin = createClient(config.apiUrl, config.serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
const observations = [], fixtures = { tenantId: randomUUID(), foreignTenantId: randomUUID(), branchId: randomUUID(), otherBranchId: randomUUID(), courseId: randomUUID(), actors: [] };
let server, serverLog;
function save() { fs.writeFileSync(path.join(directory, 'HTTP_RESULTS.json'), JSON.stringify({ at: new Date().toISOString(), target: config.target,
  source: fingerprint(), observations, credentialsPersisted: false, goLive: 'NOT_PROVEN' }, null, 2)); }
function fingerprint() {
  const tracked = execFileSync('git', ['diff','HEAD','--name-only','--','src','tests','supabase/migrations'], {cwd:root,encoding:'utf8'});
  const untracked = execFileSync('git', ['ls-files','-o','--exclude-standard','src','tests','supabase/migrations'], {cwd:root,encoding:'utf8'});
  const paths = (tracked+'\n'+untracked).trim().split(/\r?\n/).filter(Boolean).sort();
  const files = [...new Set(paths)].map(file => ({file,sha256:createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')}));
  return { head: execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(), files,
    manifestSha256:createHash('sha256').update(JSON.stringify(files)).digest('hex'),dirty:true };
}
function step(name, evidence) { observations.push({ name, result:'PASS', ...evidence }); save(); console.log(JSON.stringify({name,result:'PASS'})); }
function checked(error, label) { if (error) throw new Error(label + ': ' + error.message); }
async function startServer() {
  const log = fs.createWriteStream(path.join(directory, 'NEXT_' + (observations.length) + '.log'), {flags:'wx'}); serverLog=log;
  server = spawn(process.execPath, [path.join(dependencyRoot,'next/dist/bin/next'),'dev','--webpack','--hostname','127.0.0.1','--port',String(port)],
    {cwd:runtime,env:config.serverEnv,stdio:['ignore','pipe','pipe'],windowsHide:true});
  const redact = data => log.write(String(data).replace(/(eyJ[A-Za-z0-9._-]{30,}|sb_secret_[A-Za-z0-9_-]+)/g,'[REDACTED_TOKEN]'));
  server.stdout.on('data',redact);server.stderr.on('data',redact);
  for(let i=0;i<30;i++) {
    if (server.exitCode!==null) throw new Error('NEXT_SERVER_EXITED_' + server.exitCode);
    try { const r=await fetch(origin+'/api/education/finance',{signal:AbortSignal.timeout(3000)});if(r.status===401)return; } catch {}
    await new Promise(resolve=>setTimeout(resolve,1000));
  }
  throw new Error('NEXT_SERVER_READINESS_NOT_PROVEN');
}
async function stopServer() {
  if(server && server.exitCode===null) {
    spawnSync('taskkill',['/PID',String(server.pid),'/T','/F'],{windowsHide:true,stdio:'ignore'});
    await new Promise(resolve=>server.exitCode!==null?resolve():server.once('exit',resolve));
  }
  serverLog?.end();server=undefined;
}
async function actor(role,tenant=fixtures.tenantId) {
  const password=randomUUID()+randomUUID(),email='preschool-chain-'+randomUUID()+'@example.test';
  const made=await admin.auth.admin.createUser({email,password,email_confirm:true});checked(made.error,'Auth fixture');
  const id=made.data.user.id,personId=randomUUID();
  await db.query("INSERT INTO public.users(id,tenant_id,email,full_name,role,status) VALUES($1,$2,$3,'Controlled Chain actor',$4,'active')",[id,tenant,email,role]);
  await db.query("INSERT INTO public.people_directory(id,tenant_id,user_id,person_type,display_name,is_active) VALUES($1,$2,$3,'employee','Controlled Chain actor',true)",[personId,tenant,id]);
  let relationshipId=null;
  if(tenant===fixtures.tenantId){relationshipId=randomUUID();await db.query("INSERT INTO public.org_relationships(id,tenant_id,from_id,from_type,to_id,to_type,rel_type) VALUES($1,$2,$3,'person',$4,'unit','belongs_to')",[relationshipId,tenant,personId,fixtures.branchId]);}
  const jar=new Map();const signed=createServerClient(config.apiUrl,config.anonKey,{cookies:{getAll:()=>Array.from(jar,([name,value])=>({name,value})),setAll:values=>values.forEach(c=>jar.set(c.name,c.value))}});
  const login=await signed.auth.signInWithPassword({email,password});checked(login.error,'sign in');assert.equal(login.data.user.id,id);
  fixtures.actors.push({id,personId,relationshipId,tenant,role});fs.writeFileSync(path.join(directory,'FIXTURE_IDS.json'),JSON.stringify(fixtures,null,2));
  return {id,personId,relationshipId,signed,jar,cookie:()=>Array.from(jar,([name,value])=>name+'='+value).join('; ')};
}
async function http(who,route,body) {
  const r=await fetch(origin+route,{method:body===undefined?'GET':'POST',headers:{...(who?{cookie:who.cookie()}:{}),'Content-Type':'application/json'},
    ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(90000)});
  const text=await r.text();let data;try{data=JSON.parse(text)}catch{throw new Error('HTTP_NON_JSON_'+r.status+'_'+route);}
  return {status:r.status,data};
}
function expectStatus(result,status,label) { if(result.status!==status)throw new Error(label+': HTTP '+result.status+' '+JSON.stringify(result.data).slice(0,500)); }
async function rows(table) { return (await db.query(`SELECT to_jsonb(t) AS data FROM public.${table} t WHERE tenant_id=$1 ORDER BY to_jsonb(t)::text`,[fixtures.tenantId])).rows.map(r=>r.data); }
async function financialState() { const out={};for(const name of ['edu_fin_invoices','edu_fin_payments','edu_fin_reconciliation_ledger','edu_fin_receipts','edu_fin_reconciliation_operations'])out[name]=await rows(name);return out; }
async function main(){
  let phase='preflight';
  try {
    await db.connect();await db.query("SET statement_timeout='30s'");
    const applied=(await db.query('SELECT version FROM supabase_migrations.schema_migrations WHERE version=ANY($1::text[])',[JSON.parse(fs.readFileSync(path.join(__dirname,'TARGET_APPLY_PLAN.json'))).manifest.map(m=>m.version)])).rowCount;assert.equal(applied,20);
    phase='http_start';prepareRuntime();await startServer();step('next_real_http_server',{origin,runtime,nodeEnv:'development',authBypass:false});
    await db.query("INSERT INTO public.tenants(id,name,status,product_key) VALUES($1,'Controlled Preschool Chain E2E','active','bella_preschool'),($2,'Controlled Foreign Chain E2E','active','bella_preschool')",[fixtures.tenantId,fixtures.foreignTenantId]);
    await db.query("INSERT INTO public.org_units(id,tenant_id,unit_type,name,is_active) VALUES($1,$3,'branch','Controlled Chain branch A',true),($2,$3,'branch','Controlled Chain branch B',true)",[fixtures.branchId,fixtures.otherBranchId,fixtures.tenantId]);
    await db.query("INSERT INTO public.edu_courses(id,tenant_id,course_code,title,status,max_students,current_enrollment,prerequisite_course_codes) VALUES($1,$2,$3,'Controlled Chain class A','active',20,0,'{}')",[fixtures.courseId,fixtures.tenantId,'CHAIN-'+randomUUID()]);
    phase='auth';const owner=await actor('admin'),teacher=await actor('admin_staff'),accountant=await actor('accountant'),foreign=await actor('admin',fixtures.foreignTenantId);
    const profile=await owner.signed.rpc('platform_current_actor_profile');checked(profile.error,'current actor contract');assert.equal(profile.data.length,1);assert.equal(profile.data[0].id,owner.id);assert.equal(profile.data[0].tenant_id,fixtures.tenantId);assert.ok(!('password_hash' in profile.data[0]));
    step('real_auth_canonical_profile',{actorId:owner.id,tenantId:fixtures.tenantId});
    phase='admission';const operationKey=randomUUID();
    const form={operationKey,childName:'Controlled Chain Child '+operationKey.slice(0,6),nickname:'Proof',dateOfBirth:'2023-06-15',gender:'male',guardianName:'Controlled Chain Guardian',guardianPhone:'09'+String(BigInt('0x'+randomUUID().replaceAll('-','').slice(0,10))%100000000n).padStart(8,'0'),medicalNote:'Controlled Non-Production proof',courseId:fixtures.courseId,branchId:fixtures.branchId};
    expectStatus(await http(null,'/api/education/enrollments',form),401,'anonymous admission');
    expectStatus(await http(teacher,'/api/education/enrollments',form),403,'staff admission');
    expectStatus(await http(owner,'/api/education/enrollments',{...form,tenantId:fixtures.foreignTenantId}),403,'foreign tenant admission');
    step('admission_auth_negative_no_write',{operations:(await rows('preschool_admission_operations')).length});assert.equal((await rows('preschool_admission_operations')).length,0);
    const [admitted,initialRace]=await Promise.all([http(owner,'/api/education/enrollments',form),http(owner,'/api/education/enrollments',form)]);
    expectStatus(admitted,201,'admission create');expectStatus(initialRace,201,'initial concurrent admission');
    const enrollmentId=admitted.data.enrollment.id,studentPartyId=admitted.data.student.partyId;
    assert.equal(initialRace.data.enrollment.id,enrollmentId);assert.equal(initialRace.data.student.partyId,studentPartyId);
    assert.equal((await rows('students')).length,1);
    const retry=await http(owner,'/api/education/enrollments',{operationKey});expectStatus(retry,201,'admission recovery');assert.equal(retry.data.enrollment.id,enrollmentId);assert.equal(retry.data.student.partyId,studentPartyId);
    const concurrent=await Promise.all([http(owner,'/api/education/enrollments',{operationKey}),http(owner,'/api/education/enrollments',{operationKey})]);concurrent.forEach(r=>{expectStatus(r,201,'concurrent admission recovery');assert.equal(r.data.enrollment.id,enrollmentId);});
    expectStatus(await http(owner,'/api/education/enrollments',{...form,childName:form.childName+' changed'}),409,'admission payload conflict');
    assert.equal((await rows('edu_enrollments')).length,1);assert.equal((await rows('edu_enrollment_event_records')).length,1);
    step('admission_canonical_retry_concurrency_event_capture',{operationKey,enrollmentId,studentPartyId,enrollments:1,eventRecords:1});
    phase='attendance';const day='2026-10-23',time='2026-10-23T05:00:00.000Z';
    const denied=await teacher.signed.rpc('preschool_set_scoped_daily_attendance',{p_tenant_id:fixtures.tenantId,p_actor_id:teacher.id,p_expected_role:'admin_staff',p_branch_id:fixtures.branchId,p_enrollment_id:enrollmentId,p_course_id:fixtures.courseId,p_student_party_id:studentPartyId,p_status:'present',p_roll_call_time:time,p_school_day:day});assert.ok(denied.error);assert.equal(denied.error.code,'42501');assert.equal((await rows('edu_attendance')).length,0);
    expectStatus(await http(foreign,'/api/education/attendance',{enrollmentId,status:'present',date:day}),403,'foreign attendance');assert.equal((await rows('edu_attendance')).length,0);
    const attend=await http(teacher,'/api/education/attendance',{enrollmentId,status:'present',date:day});expectStatus(attend,200,'attendance');assert.equal(attend.data.attendance.enrollmentId,enrollmentId);assert.equal((await rows('edu_attendance')).length,1);
    const roster=await http(teacher,'/api/education/attendance?courseId='+fixtures.courseId+'&date='+day);expectStatus(roster,200,'attendance readback');assert.equal(roster.data.roster[0].attendance.status,'present');
    const beforeRevoke=JSON.stringify(await rows('edu_attendance'));await db.query('DELETE FROM public.org_relationships WHERE id=$1 AND tenant_id=$2',[teacher.relationshipId,fixtures.tenantId]);
    expectStatus(await http(teacher,'/api/education/attendance',{enrollmentId,status:'absent',date:day}),403,'revoked attendance');assert.equal(JSON.stringify(await rows('edu_attendance')),beforeRevoke);
    step('attendance_http_auth_branch_revocation_readback',{enrollmentId,directRpcDenied:true,foreignTenantDenied:true,events:1,revokedWriteUnchanged:true});
    phase='finance_setup';const period=randomUUID();
    await db.query("INSERT INTO public.edu_fin_billing_periods(id,tenant_id,period_name,start_date,end_date,due_date,status,created_by) VALUES($1,$2,'Controlled October proof','2026-10-01','2026-10-31','2026-11-05','ACTIVE',$3)",[period,fixtures.tenantId,owner.id]);
    await db.query("INSERT INTO public.edu_fin_fee_structures(tenant_id,fee_code,fee_name,fee_type,amount,program_id) VALUES($1,$2,'Controlled tuition','TUITION',1000000,'PRESCHOOL')",[fixtures.tenantId,'PROOF-'+randomUUID()]);
    let state=await http(accountant,'/api/education/finance?branchId='+fixtures.branchId);expectStatus(state,200,'finance read');
    const draft=await http(accountant,'/api/education/finance',{action:'compileDraftInvoice',branchId:fixtures.branchId,studentPartyId,billingPeriodId:period});expectStatus(draft,200,'compile draft');const invoiceId=draft.data.invoice.id;
    const issued=await http(accountant,'/api/education/finance',{action:'issueInvoice',branchId:fixtures.branchId,invoiceId});expectStatus(issued,200,'issue invoice');assert.equal(issued.data.invoice.invoiceStatus,'ISSUED');
    const paymentKey=randomUUID(),pay={action:'recordAndReconcilePayment',branchId:fixtures.branchId,invoiceId,operationKey:paymentKey,paymentAmount:250000,paymentMethod:'CASH'};
    const beforeDenied=JSON.stringify(await financialState());expectStatus(await http(accountant,'/api/education/finance',{...pay,branchId:fixtures.otherBranchId}),403,'other branch finance');expectStatus(await http(foreign,'/api/education/finance',pay),403,'foreign finance');assert.equal(JSON.stringify(await financialState()),beforeDenied);
    phase='payment_lost_ack';
    // Execute the real HTTP request and deliberately discard its response. SQL proves commit, not a fabricated response.
    const response=await fetch(origin+'/api/education/finance',{method:'POST',headers:{cookie:accountant.cookie(),'Content-Type':'application/json'},body:JSON.stringify(pay),signal:AbortSignal.timeout(90000)});assert.equal(response.status,200);await response.body.cancel();
    const committed=await financialState();assert.equal(committed.edu_fin_payments.length,1);assert.equal(committed.edu_fin_receipts.length,1);assert.equal(committed.edu_fin_reconciliation_operations.length,1);
    const firstServerPid=server.pid;await stopServer();await startServer();assert.notEqual(server.pid,firstServerPid);
    const recovered=await http(accountant,'/api/education/finance',pay);expectStatus(recovered,200,'payment process restart recovery');assert.equal(JSON.stringify(await financialState()),JSON.stringify(committed));
    const paymentConcurrent=await Promise.all([http(accountant,'/api/education/finance',pay),http(accountant,'/api/education/finance',pay)]);paymentConcurrent.forEach(r=>expectStatus(r,200,'payment concurrent recovery'));assert.equal(JSON.stringify(await financialState()),JSON.stringify(committed));
    expectStatus(await http(accountant,'/api/education/finance',{...pay,paymentAmount:250001}),409,'payment payload conflict');assert.equal(JSON.stringify(await financialState()),JSON.stringify(committed));
    const admissionRestart=await http(owner,'/api/education/enrollments',{operationKey});expectStatus(admissionRestart,201,'admission process restart');assert.equal(admissionRestart.data.enrollment.id,enrollmentId);
    step('finance_http_lost_ack_restart_retry_conflict',{invoiceId,paymentKey,paymentId:committed.edu_fin_payments[0].id,receiptId:committed.edu_fin_receipts[0].id,firstServerPid,secondServerPid:server.pid,counts:{payments:1,receipts:1,operations:1}});
    phase='browser';await browserProof({owner,accountant,enrollmentId,studentPartyId,invoiceId,form});
    step('target_http_verification_complete',{downstreamEventConsumer:'NOT_PROVEN',remoteCi:'NOT_PROVEN'});
  } catch(error) {
    observations.push({name:phase,result:'FAIL',code:error.code??null,error:String(error.message).replace(/(eyJ[A-Za-z0-9._-]{30,}|sb_secret_[A-Za-z0-9_-]+)/g,'[REDACTED]').slice(0,1100)});save();console.error(JSON.stringify({phase,result:'FAIL',error:observations.at(-1).error}));process.exitCode=1;
  } finally {await stopServer();await db.end();save();console.log(JSON.stringify({packet:directory,passed:observations.filter(r=>r.result==='PASS').length,failed:observations.filter(r=>r.result==='FAIL').length}));}
}
async function browserProof({owner,accountant,form}) {
  const {chromium}=require('playwright');const {expect}=require('@playwright/test');const browser=await chromium.launch({headless:true});
  try{
    for(const [name,who,route] of [['registry',owner,'/dashboard/education/enrollments'],['attendance',owner,'/dashboard/education/attendance'],['finance',accountant,'/dashboard/education/finance']]) {
      const context=await browser.newContext({viewport:{width:1440,height:1100}});
      await context.addCookies(Array.from(who.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));
      const page=await context.newPage();await page.goto(origin+route,{waitUntil:'domcontentloaded',timeout:120000});
      if(name==='attendance')await expect(page.locator('tr').filter({hasText:form.childName})).toBeVisible({timeout:90000});
      else if(name==='registry')await expect(page.getByText(form.childName,{exact:true}).first()).toBeVisible({timeout:90000});
      else {await expect(page.getByRole('combobox',{name:/cơ sở/i})).toBeVisible({timeout:90000});}
      await page.screenshot({path:path.join(directory,'BROWSER_'+name+'.png'),fullPage:true});
      step('browser_'+name+'_real_api_read',{url:route});await context.close();
    }
  }finally{await browser.close();}
}
if (require.main === module) main();
module.exports = { db, admin, fixtures, directory, origin, config, prepareRuntime, startServer, stopServer,
  step, save, observations, http, expectStatus, rows, financialState, fingerprint };
