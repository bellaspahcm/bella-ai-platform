# Exact Non-Production target provisioning decision

Status: PENDING APPROVAL. No target migration or ACL change has been executed.

Target: `bmnbqbcdbuklhopfbopv.supabase.co`, using only the configured `DATABASE_EXECUTOR_URL_TEST` from the main checkout's `.env.e2e`. No credential value is recorded.

Read-only metadata on 2026-10-23: 133 history entries, no remote-only version against the integrated source; 14/14 Chain migrations absent. The target lacks Attendance event/assessment tables, all nine P6 tables, all eight P71 tables and both tuition-policy tables. Existing enrollment request uniqueness and daily-state constraint match the required named constraints. Static named-object dependency closure has no unresolved references; this is not executable migration proof.

## Exact migration allowlist

Six canonical prerequisites, unmodified:

1. `20260813000020_create_edu_attendance_and_assessment.sql`
2. `20260909000056_p61_parent_communication.sql`
3. `20260909000057_p62_projection_bridges.sql`
4. `20260909000058_p71_preschool_finance.sql`
5. `20260927070000_preschool_finance_canonical_student_party.sql`
6. `20260928000000_preschool_tuition_recognition_policy_foundation.sql`

Then the 14 already-reviewed Chain migrations, in version order. Exact filenames, SHA256 values, new tables/functions/sequences and dependency inventory are in `TARGET_APPLY_PLAN.json`. Do not select other pending migrations. There are 430 historical baseline versions absent from history; they are not permission to backfill or mark history applied.

## Proposed execution and verification

- Revalidate project identity, source hashes, history and the exact absent prerequisite objects before writes. Stop on drift or collisions.
- Run the exact 20 files as one transaction, removing only their outer transaction wrappers in the executor so a canonical inner `COMMIT` cannot escape the bundle. Keep canonical files unchanged. Use a bounded lock/statement timeout and advisory migration lock; on any error roll back the entire transaction and stop.
- Record only these 20 successfully executed versions with their actual source statements. Preserve all 133 existing history rows. No placeholder reconciliation, migration-history repair, `db push`, seed or business-data mutation.
- Within that transaction, inspect and revoke direct `TRUNCATE` for `anon` and `authenticated` on the 21 new prerequisite tables and the existing `edu_attendance_daily_state` only (22 named tables, at most 44 role/table pairs). Feature-owned receipt/event tables already revoke all client grants. Retain defaults and every other grant outside the reviewed feature migrations. SQL effective privilege read-back must also detect inheritance; do not silently alter role membership/defaults if a direct revoke is insufficient.
- Read back schema, functions, RLS, ACL and history. Compare counts/digests for existing scoped data and unchanged metadata; retain only counts/digests, not application rows or credentials. Update PostgREST schema visibility only if needed through the approved target mechanism.
- After schema gate PASS, run the approved controlled Auth/RLS/API/recovery/browser tests with isolated fixtures on this target. Preserve old evidence separately, bind all new results to the final working-source fingerprint and do not claim downstream enrollment consumer processing without a consumer contract.

Pre-commit failure recovery: transaction rollback, then metadata/history/data digest read-back. After a successful commit, do not drop tables or erase history to roll back; hold affected workflows and request an owner-approved forward correction if verification fails.

No Production access, unrelated Kernel/schema changes, default privilege changes, commit/push/PR/merge/deploy or required-check/ruleset changes are included. Existing local-only migration approvals do not by themselves authorize provisioning this shared E2E target.
