# One canonical prerequisite missed by SQL-only dependency closure

Pending target-specific approval; no apply performed.

Executed E2E evidence: `http-2026-10-23T02-38-27-046Z/HTTP_RESULTS.json`. Admission concurrent creation/recovery and event capture PASS; Attendance POST returned 200 and SQL read-back found its event. GET roster returned 500: `public.edu_preschool_pickup_handover_events` absent. The read path invokes `PreschoolSafePickupHandoverService` even when no handover exists. The earlier 20-file dependency closure covered named SQL references, not every API reader; its limitation is retained.

Exact target extension: apply the unmodified canonical `supabase/migrations/20260927030000_preschool_safe_pickup_handover_events.sql`, SHA256 `17d5ca4cf8b5265fb36e4e93f4c86ca5254701a1745d039c836fb99bda066a73`, on E2E `bmnbqbcdbuklhopfbopv` only. It creates one Product table, three indexes, tenant RLS/policy and a comment. All named FK targets and `get_auth_tenant_id` already exist. No seed or runtime change is required.

In one transaction: recheck source hash, absent table and absent ledger version; apply exact SQL; revoke only direct `TRUNCATE` from `anon` and `authenticated` on this new table; insert only version `20260927030000` with actual source SQL in migration history; read back effective privilege denial, table/RLS/index definitions and unchanged existing metadata/data digests. Notify PostgREST to reload schema on commit. Preserve all earlier history, defaults, data, test fixtures and packets. On any pre-commit error roll back the transaction; do not silently repair history or other schema.

After approval, resume the existing run-owned Auth/tenant fixtures for Attendance GET, authorization denial/read-back and browser verification. Existing successful data is retained. Keep target schema provisioning distinct from proof of direct Auth/RLS or complete branch safety. No Production or delivery authority is included.
