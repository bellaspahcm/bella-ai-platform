const fs=require('node:fs'),path=require('node:path');const {Client}=require('pg');const config=require('./target-env.cjs');
const before=JSON.parse(fs.readFileSync(path.join(__dirname,'TARGET_AFTER.json')));const tenants=new Set();
for(const name of fs.readdirSync(__dirname).filter(n=>n.startsWith('http-'))){const file=path.join(__dirname,name,'FIXTURE_IDS.json');if(fs.existsSync(file)){const f=JSON.parse(fs.readFileSync(file));tenants.add(f.tenantId);tenants.add(f.foreignTenantId);}}
const quote=n=>'"'+n.replaceAll('"','""')+'"';
(async()=>{const db=new Client({connectionString:config.dbUrl,ssl:{rejectUnauthorized:false},connectionTimeoutMillis:15000});try{
await db.connect();await db.query('BEGIN READ ONLY');await db.query("SET LOCAL statement_timeout='30s'");
const columns=(await db.query("SELECT table_name,column_name FROM information_schema.columns WHERE table_schema='public'")).rows;
const data=[];for(const table of before.data){const filter=table.name==='tenants'?'WHERE NOT (t.id::text=ANY($1::text[]))':columns.some(c=>c.table_name===table.name&&c.column_name==='tenant_id')?'WHERE NOT (t.tenant_id::text=ANY($1::text[])) OR t.tenant_id IS NULL':'';
const query=`SELECT count(*)::text AS count,md5(coalesce(string_agg(row_digest,'' ORDER BY row_digest),'')) AS digest FROM (SELECT md5(to_jsonb(t)::text) AS row_digest FROM public.${quote(table.name)} t ${filter}) q`;
const r=(await db.query(query,filter?[[...tenants]]:[])).rows[0];data.push({name:table.name,...r,unchanged:r.count===table.count&&r.digest===table.digest});}
const history=(await db.query('SELECT version,name,md5(statements::text) AS statements_md5 FROM supabase_migrations.schema_migrations ORDER BY version')).rows;
const defaults=(await db.query('SELECT defaclrole::regrole::text AS owner,defaclnamespace::regnamespace::text AS schema,defaclobjtype,defaclacl::text FROM pg_default_acl ORDER BY 1,2,3')).rows;
const policies=(await db.query("SELECT tablename,policyname,roles,cmd,qual,with_check FROM pg_policies WHERE schemaname='public' ORDER BY 1,2")).rows;
const tables=(await db.query("SELECT c.relname AS name,c.relrowsecurity,c.relforcerowsecurity,c.relacl::text AS acl FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY 1")).rows;
const functions=(await db.query("SELECT p.proname AS name,pg_get_function_identity_arguments(p.oid) AS args,p.proacl::text AS acl,md5(pg_get_functiondef(p.oid)) AS definition_md5 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.prokind='f' ORDER BY 1,2")).rows;
await db.query('ROLLBACK');const result={at:new Date().toISOString(),target:config.target,mode:'READ_ONLY',runOwnedTenantsExcluded:tenants.size,oldDataUnchanged:data.every(r=>r.unchanged),data,
historyUnchanged:JSON.stringify(before.history)===JSON.stringify(history),defaultsUnchanged:JSON.stringify(before.defaults)===JSON.stringify(defaults),policiesUnchanged:JSON.stringify(before.policies)===JSON.stringify(policies),tableAclRlsUnchanged:JSON.stringify(before.tables)===JSON.stringify(tables),functionsUnchanged:JSON.stringify(before.functions)===JSON.stringify(functions)};
fs.writeFileSync(path.join(__dirname,'POST_VERIFICATION_INTEGRITY.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({...result,data:result.data.filter(r=>!r.unchanged)}));if(!['oldDataUnchanged','historyUnchanged','defaultsUnchanged','policiesUnchanged','tableAclRlsUnchanged','functionsUnchanged'].every(k=>result[k]))process.exitCode=1;
}catch(e){console.error(JSON.stringify({code:e.code??null,message:'INTEGRITY_CHECK_FAILED',details:String(e.message).replace(/postgres(?:ql)?:\/\/[^\s]+/g,'[REDACTED]')}));process.exitCode=1;}finally{await db.end();}})();
