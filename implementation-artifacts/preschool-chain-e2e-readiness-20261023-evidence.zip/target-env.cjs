const fs = require('node:fs');
const { parse } = require('dotenv');
const target = 'bmnbqbcdbuklhopfbopv';
const env = parse(fs.readFileSync('D:/Antigravity/Projects/BELLA SPA ERP/.env.e2e'));
if (new URL(env.NEXT_PUBLIC_SUPABASE_URL).hostname !== target + '.supabase.co') throw new Error('E2E_API_GUARD_DENIED');
const dbUrl = env.DATABASE_EXECUTOR_URL_TEST?.trim();
if (!dbUrl) throw new Error('E2E_EXECUTOR_REQUIRED_NO_FALLBACK');
const db = new URL(dbUrl);
if (!['postgres:', 'postgresql:'].includes(db.protocol)
  || (!db.hostname.includes(target) && !decodeURIComponent(db.username).endsWith('.' + target))) throw new Error('E2E_DB_GUARD_DENIED');
if (!env.SUPABASE_SERVICE_ROLE_KEY || !env.NEXT_PUBLIC_SUPABASE_ANON_KEY) throw new Error('E2E_AUTH_CONFIGURATION_REQUIRED');
module.exports = { target, dbUrl, apiUrl: env.NEXT_PUBLIC_SUPABASE_URL,
  serviceKey: env.SUPABASE_SERVICE_ROLE_KEY, anonKey: env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  serverEnv: { ...process.env, NODE_ENV: 'development', DEPLOYMENT_ENV: 'staging',
    NEXT_TELEMETRY_DISABLED: '1', NEXT_PUBLIC_SUPABASE_URL: env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    SUPABASE_SERVICE_ROLE_KEY: env.SUPABASE_SERVICE_ROLE_KEY, SUPABASE_SECRET_KEY: env.SUPABASE_SERVICE_ROLE_KEY,
    SUPABASE_URL: env.NEXT_PUBLIC_SUPABASE_URL } };
