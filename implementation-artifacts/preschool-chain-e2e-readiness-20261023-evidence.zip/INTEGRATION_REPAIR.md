# Bounded integration repair

Source: `80e13ea92ee70742d26cd890a45aaa94d8fc7494` plus the preserved uncommitted Chain integration. Existing human-approved Non-Production Attendance command/public-contract scope applies. No Factory execution is claimed.

Root cause: the integration adapter called Education's generic scoped command instead of the approved Preschool Product command. That omitted Product assignment locks/action policy from the DB transaction. Restore the exact `preschool_set_scoped_daily_attendance` boundary through the public contract; preserve Education's generic command for its existing callers.

Allowlist: Attendance public command contract/implementation and owner tests, Preschool Attendance command service and its focused routing tests, Attendance page formatting and UI regression tests. No SQL, schema, grants, protected manifests or other runtime changes.

UI reconciliation: the integrated UI invalidates an uncertain POST's roster and requires an authorized GET before retry. Retain this safety behavior. Update the eight stale-cache test cases to verify blocked actions, canonical read-back and retry only after successful read-back; add denial-after-uncertain-write coverage. Preserve confirmation validation and no-success-on-error assertions.

Verify: focused Attendance contract/Product/UI tests, affected API unit tests, TypeScript, ESLint, Education no-new-debt/architecture guards and diff checks. These do not establish Real DB/browser or Go-Live proof for the new source. Target E2E provisioning is held separately pending a concrete prerequisite migration plan and target-specific approval.

## Proven follow-up fixes within existing approved Product/UI scope

- Real HTTP payload conflict returned 500 because the Product admission adapter propagated a typed Platform error that the route did not recognize. Translate the public operation error into `PreschoolAdmissionError`, preserving its approved code/status. Regression verifies the Product error class as well as status 409; actual HTTP rerun returned 409 without a replacement enrollment.
- Finance buttons retained the main UI's old payment modal, whose POST omitted the required stable operation key; the integrated durable dialog was unreachable. Route invoice-specific buttons to the durable dialog. The general invoice picker hands its canonical selection/amount/method to that same dialog and performs no financial write. Existing retained intent takes precedence. Keep all payment mutation in the original approved `submitPayment` path with localStorage-before-fetch and browser lock.
- Narrow the picker's payment-method state to the existing durable intent union (`BANK_TRANSFER`, `CASH`, `QR_CODE`), matching all three rendered controls. Do not add accounting or payment-method semantics.
- Preserve environment failures, stale generated-type diagnostics, HTTP failures and harness selector failures as separate raw evidence. Final source proof must use the new hashes; previous revisions' successful cases remain bounded prior evidence.
