const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {randomUUID}=require('node:crypto');const {createServerClient}=require('@supabase/ssr');
const h=require('./run-target-http.cjs');
const prior=path.join(__dirname,'http-2026-10-23T02-38-27-046Z');
Object.assign(h.fixtures,JSON.parse(fs.readFileSync(path.join(prior,'FIXTURE_IDS.json'))));
fs.writeFileSync(path.join(h.directory,'FIXTURE_IDS.json'),JSON.stringify(h.fixtures,null,2));
async function signInFixture(role,tenant=h.fixtures.tenantId){
  const f=h.fixtures.actors.find(a=>a.role===role&&a.tenant===tenant);assert.ok(f);
  const canonical=(await h.db.query('SELECT id,tenant_id,role,status,email FROM public.users WHERE id=$1 AND tenant_id=$2',[f.id,tenant])).rows[0];
  assert.equal(canonical.role,role);assert.equal(canonical.status,'active');assert.match(canonical.email,/^preschool-chain-.*@example\.test$/);
  const auth=await h.admin.auth.admin.getUserById(f.id);if(auth.error)throw auth.error;assert.equal(auth.data.user.email,canonical.email);
  // Run-owned test identity only. Generate/verify a one-time link without sending email,
  // resetting a password, persisting credentials or changing canonical authority.
  const link=await h.admin.auth.admin.generateLink({type:'magiclink',email:canonical.email});if(link.error)throw link.error;
  assert.equal(link.data.user.id,f.id);const jar=new Map();
  const signed=createServerClient(h.config.apiUrl,h.config.anonKey,{cookies:{getAll:()=>Array.from(jar,([name,value])=>({name,value})),setAll:items=>items.forEach(c=>jar.set(c.name,c.value))}});
  const login=await signed.auth.verifyOtp({token_hash:link.data.properties.hashed_token,type:'magiclink'});if(login.error)throw login.error;assert.equal(login.data.user.id,f.id);
  return {...f,jar,signed,cookie:()=>Array.from(jar,([name,value])=>name+'='+value).join('; ')};
}
async function main(){let phase='resume_preflight';try{
  await h.db.connect();await h.db.query("SET statement_timeout='30s'");
  const operation=(await h.rows('preschool_admission_operations'));assert.equal(operation.length,1);
  const enrollments=await h.rows('edu_enrollments');assert.equal(enrollments.length,1);const enrollment=enrollments[0];
  const owner=await signInFixture('admin'),accountant=await signInFixture('accountant'),foreign=await signInFixture('admin',h.fixtures.foreignTenantId);
  h.prepareRuntime();await h.startServer();h.step('resume_existing_canonical_fixture',{prior: path.basename(prior),operationKey:operation[0].operation_key,enrollmentId:enrollment.id,noDuplicateProvisioning:true});
  phase='finance_setup';assert.equal((await h.rows('edu_fin_invoices')).length,0);
  const period=randomUUID();await h.db.query("INSERT INTO public.edu_fin_billing_periods(id,tenant_id,period_name,start_date,end_date,due_date,status,created_by) VALUES($1,$2,'Controlled October proof','2026-10-01','2026-10-31','2026-11-05','ACTIVE',$3)",[period,h.fixtures.tenantId,owner.id]);
  await h.db.query("INSERT INTO public.edu_fin_fee_structures(tenant_id,fee_code,fee_name,fee_type,amount,program_id) VALUES($1,$2,'Controlled tuition','TUITION',1000000,'PRESCHOOL')",[h.fixtures.tenantId,'PROOF-'+randomUUID()]);
  const state=await h.http(accountant,'/api/education/finance?branchId='+h.fixtures.branchId);h.expectStatus(state,200,'finance read');
  const draft=await h.http(accountant,'/api/education/finance',{action:'compileDraftInvoice',branchId:h.fixtures.branchId,studentPartyId:enrollment.student_party_id,billingPeriodId:period});h.expectStatus(draft,200,'compile draft');const invoiceId=draft.data.invoice.id;
  const issued=await h.http(accountant,'/api/education/finance',{action:'issueInvoice',branchId:h.fixtures.branchId,invoiceId});h.expectStatus(issued,200,'issue invoice');assert.equal(issued.data.invoice.invoiceStatus,'ISSUED');
  h.step('finance_http_read_compile_issue',{invoiceId,period,netAmount:issued.data.invoice.netAmount});
  const pay={action:'recordAndReconcilePayment',branchId:h.fixtures.branchId,invoiceId,operationKey:randomUUID(),paymentAmount:250000,paymentMethod:'CASH'};
  const deniedBefore=JSON.stringify(await h.financialState());h.expectStatus(await h.http(accountant,'/api/education/finance',{...pay,branchId:h.fixtures.otherBranchId}),403,'other branch finance');h.expectStatus(await h.http(foreign,'/api/education/finance',pay),403,'foreign finance');assert.equal(JSON.stringify(await h.financialState()),deniedBefore);
  h.step('finance_http_foreign_tenant_and_branch_denied',{noFinancialSideEffect:true});
  phase='payment_lost_ack';const response=await fetch(h.origin+'/api/education/finance',{method:'POST',headers:{cookie:accountant.cookie(),'Content-Type':'application/json'},body:JSON.stringify(pay),signal:AbortSignal.timeout(90000)});
  if(response.status!==200)throw new Error('PAYMENT_HTTP_'+response.status+': '+(await response.text()).slice(0,500));await response.body.cancel();
  const committed=await h.financialState();assert.equal(committed.edu_fin_payments.length,1);assert.equal(committed.edu_fin_receipts.length,1);assert.equal(committed.edu_fin_reconciliation_operations.length,1);
  await h.stopServer();await h.startServer();const recovered=await h.http(accountant,'/api/education/finance',pay);h.expectStatus(recovered,200,'payment restart recovery');assert.equal(recovered.data.payment.id,committed.edu_fin_payments[0].id);assert.equal(recovered.data.receipt.id,committed.edu_fin_receipts[0].id);assert.equal(JSON.stringify(await h.financialState()),JSON.stringify(committed));
  const concurrent=await Promise.all([h.http(accountant,'/api/education/finance',pay),h.http(accountant,'/api/education/finance',pay)]);concurrent.forEach(r=>h.expectStatus(r,200,'concurrent recovery'));assert.equal(JSON.stringify(await h.financialState()),JSON.stringify(committed));
  h.expectStatus(await h.http(accountant,'/api/education/finance',{...pay,paymentAmount:250001}),409,'payment conflict');assert.equal(JSON.stringify(await h.financialState()),JSON.stringify(committed));
  const admission=await h.http(owner,'/api/education/enrollments',{operationKey:operation[0].operation_key});h.expectStatus(admission,201,'admission restart recovery');assert.equal(admission.data.enrollment.id,enrollment.id);
  h.step('finance_http_lost_ack_process_restart_concurrent_recovery_conflict',{invoiceId,paymentId:committed.edu_fin_payments[0].id,receiptId:committed.edu_fin_receipts[0].id,counts:{payments:1,receipts:1,operations:1}});
  phase='browser_payment';await browserPayment(accountant,invoiceId);
}catch(e){h.observations.push({name:phase,result:'FAIL',code:e.code??null,error:String(e.message).replace(/eyJ[A-Za-z0-9._-]{30,}/g,'[REDACTED]').slice(0,1200)});h.save();console.error(JSON.stringify(h.observations.at(-1)));process.exitCode=1;}
finally{await h.stopServer();await h.db.end();h.save();console.log(JSON.stringify({packet:h.directory,passed:h.observations.filter(r=>r.result==='PASS').length,failed:h.observations.filter(r=>r.result==='FAIL').length}));}}
async function browserPayment(accountant,invoiceId){const {chromium}=require('playwright'),{expect}=require('@playwright/test');const browser=await chromium.launch({headless:true});try{
  const context=await browser.newContext({viewport:{width:1440,height:1100}});await context.addCookies(Array.from(accountant.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));
  const page=await context.newPage();const sent=[];let discarded=false;
  page.on('request',r=>{if(r.url().endsWith('/api/education/finance')&&r.method()==='POST'){const b=r.postDataJSON();if(b.action==='recordAndReconcilePayment')sent.push({invoiceId:b.invoiceId,operationKey:b.operationKey,amount:b.paymentAmount});}});
  async function openInvoice(){await page.goto(h.origin+'/dashboard/education/finance?tab=invoices',{waitUntil:'domcontentloaded',timeout:120000});const branch=page.getByRole('combobox',{name:'Cơ sở tài chính'});await expect(branch).toBeEnabled({timeout:90000});await branch.click();await page.getByRole('listbox').getByRole('button',{name:'Controlled Chain branch A',exact:true}).click();await expect(page.getByTitle('Thu học phí', { exact: true }).first()).toBeVisible({timeout:90000});await page.getByTitle('Thu học phí', { exact: true }).first().click();await expect(page.getByRole('dialog',{name:'Thu học phí / khôi phục khoản thu'})).toBeVisible();}
  await openInvoice();await page.getByRole('spinbutton',{name:'Số tiền thanh toán'}).fill('100000');
  await page.route('**/api/education/finance',async route=>{if(!discarded&&route.request().method()==='POST'&&route.request().postDataJSON().action==='recordAndReconcilePayment'){const real=await route.fetch();assert.equal(real.status(),200);discarded=true;await route.abort('failed');}else await route.continue();});
  await page.getByTestId('finance-confirm-payment').click();await expect(page.getByText(/Yêu cầu đã lưu được giữ để khôi phục/)).toBeVisible({timeout:60000});assert.ok(discarded);assert.equal(sent.length,1);assert.ok(sent[0].operationKey);assert.equal(sent[0].invoiceId,invoiceId);
  const afterLost=await h.financialState();assert.equal(afterLost.edu_fin_payments.length,2);assert.equal(afterLost.edu_fin_receipts.length,2);const oldState=JSON.stringify(afterLost);
  await page.screenshot({path:path.join(h.directory,'BROWSER_PAYMENT_LOST_ACK.png'),fullPage:true});await page.unroute('**/api/education/finance');
  await openInvoice();await expect(page.getByRole('spinbutton',{name:'Số tiền thanh toán'})).toBeDisabled();await expect(page.getByRole('spinbutton',{name:'Số tiền thanh toán'})).toHaveValue('100000');
  await page.getByTestId('finance-confirm-payment').click();await expect(page.getByText(/Biên nhận:/)).toBeVisible({timeout:60000});assert.equal(sent.length,2);assert.deepEqual(sent[1],sent[0]);assert.equal(JSON.stringify(await h.financialState()),oldState);
  await page.screenshot({path:path.join(h.directory,'BROWSER_PAYMENT_RECOVERED.png'),fullPage:true});h.step('browser_payment_real_commit_response_loss_reload_recovery',{invoiceId,operationKey:sent[0].operationKey,canonicalCountsUnchanged:true,serverRequests:sent.length});
  await context.close();
}finally{await browser.close();}}
if(require.main===module)main();
module.exports={signInFixture,browserPayment};
