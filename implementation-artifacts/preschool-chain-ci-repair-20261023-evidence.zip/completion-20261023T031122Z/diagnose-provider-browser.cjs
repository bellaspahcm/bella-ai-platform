const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const h=require('../run-target-http.cjs'),{signInFixture}=require('../run-finance-resume.cjs');
(async()=>{let browser;const errors=[],parseErrors=[],pending=[],responses=[],consoles=[];try{
await h.db.connect();const teacher=await signInFixture('accountant');h.prepareRuntime();await h.startServer();
browser=await require('playwright').chromium.launch({headless:true});const context=await browser.newContext();
await context.addCookies(Array.from(teacher.jar,([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:false,secure:false,sameSite:'Lax'})));
const page=await context.newPage();page.on('pageerror',e=>errors.push({message:e.message,stack:e.stack}));
page.on('console',m=>consoles.push({type:m.type(),text:m.text().replace(/eyJ[A-Za-z0-9._-]{30,}/g,'[REDACTED]').slice(0,500)}));page.on('response',r=>responses.push({path:new URL(r.url()).pathname,status:r.status()}));
page.on('response',r=>{if(r.url().startsWith(h.origin)&&new URL(r.url()).pathname.endsWith('.js'))pending.push((async()=>{const source=await r.text().catch(()=>'');try{new vm.Script(source,{filename:new URL(r.url()).pathname});}catch(e){parseErrors.push({path:new URL(r.url()).pathname,status:r.status(),bytes:source.length,message:e.message,stack:String(e.stack).replace(/eyJ[A-Za-z0-9._-]{30,}/g,'[REDACTED]').slice(0,1700)});}})());});
await page.goto(h.origin+'/dashboard/education/finance',{waitUntil:'networkidle',timeout:120000});
await page.waitForSelector('[aria-label="Cơ sở tài chính"]',{timeout:45000}).catch(()=>{});
await Promise.allSettled(pending);const inline=await page.evaluate(()=>Array.from(document.scripts).filter(s=>!s.src&&s.type!=='application/ld+json').map(s=>{try{new Function(s.textContent||'');return null;}catch(e){return {id:s.id,type:s.type,message:String(e),snippet:s.textContent?.slice(0,300)};}}).filter(Boolean));
const result={at:new Date().toISOString(),runtime:h.directory,url:page.url(),errors,parseErrors,inline,responses,consoles,body:(await page.locator('body').innerText()).slice(0,3000)};
await page.screenshot({path:path.join(h.directory,'BROWSER_DIAGNOSTIC.png'),fullPage:true});
fs.writeFileSync(path.join(h.directory,'BROWSER_DIAGNOSTIC.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
}finally{if(browser)await browser.close();await h.stopServer();await h.db.end();}})().catch(e=>{console.error(e.message);process.exitCode=1;});
