Admission or payment can commit before the caller receives a result. This candidate preserves the operation key, reconciles canonical IDs on recovery, and keeps non-financial progress intact. Finance allocation/payment persistence uses the approved Product transaction boundary. Attendance authenticates the current actor, checks explicit tenant/branch access and canonical mappings, and rechecks authority after write/FK lock waits.

Attendance classroom discovery now uses a separate canonical endpoint, so the UI does not depend on the conflicting legacy `courses` projection. Missing capacity/age metadata stays unknown. Uncertain attendance writes require read-back before another command. Enrollment event capture/replay remains Education-owned; no operational consumer or Finance side effect was invented.

Validation on approved Non-Production E2E `bmnbqbcdbuklhopfbopv`:

- Same final source manifest: Attendance HTTP/browser 7 named cases PASS; admission/payment recovery 2 PASS; handover sequential recovery/browser read-back 2 PASS. Canonical IDs and relevant persisted rows reconciled; prior failed harness runs are retained separately.
- Endpoint unit 14 PASS; final Attendance UI 25 PASS; actor/courses/user regression 85 PASS. These counts overlap other historical suites and are not an aggregate full-system result.
- Full strict TypeScript, scoped ESLint and source diff checks PASS. Education architecture ALLOW with unchanged 248-query reviewed debt. Logistics local: 15 suites / 547 tests PASS.
- 21 scoped migrations match source hashes and approved executable history. Original row multisets across 242 tables match the documented exclusion/cutoff reconciliation. Existing history, ACL/RLS, functions and default privileges match the post-apply checkpoint. This is scoped evidence, not full target parity.

Evidence is preserved byte-for-byte in `implementation-artifacts/preschool-chain-e2e-readiness-20261023-evidence.zip` (200 files). Its adjacent JSON records archive SHA256 and tested source fingerprint `7b72cc814db67f9d5cc853fcbe643041579a8aff6600da27ec4e968fe94d3551`. `delivery-20261023T041100Z/COMMIT_SOURCE_BINDING.json` inside the archive maps raw tested bytes to staged Git content; 44 files differ only by CRLF normalization. The expanded packet remains local and unmodified. Raw evidence whitespace is preserved in the archive rather than rewritten.

Draft / HOLD:

- Obtain all four required remote checks on this exact commit; local PASS does not replace them.
- Acceptance review has no actionable findings. Blind/edge independent reviewers failed due to service usage limits, so full independent review is not sealed.
- Full migration parity remains NOT_PROVEN (419 historical pending migrations were not applied). General course/detail schema reconciliation and English Center target compatibility remain outside this repair.
- Handover concurrency and revocation-during-handover-write are NOT_PROVEN. Enrollment downstream processing remains NOT_PROVEN without an approved operational consumer/acknowledgement contract.
- P71/P72 and the prior nine business cases were retained; they were not rerun without a relevant dependency change. Healthcare remains out of repair scope.

Human authorization covers this commit, branch push, draft PR, CI and Non-Production preview. No merge, Production migration or Production deployment is authorized. FULL_CHAIN_GO_LIVE remains NOT_PROVEN.