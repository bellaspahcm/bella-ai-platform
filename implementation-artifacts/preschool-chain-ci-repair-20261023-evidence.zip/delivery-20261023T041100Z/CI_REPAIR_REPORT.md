# CI follow-up for PR418

Base candidate: `78b710013ae8a6876b3f6c16406e9cffdb70fc4c`. Four required Architecture Gate checks PASS on that exact SHA; no transfer of PASS to the next SHA.

Human additionally approved the exact shared TenantContextProvider integration (SHA256 `05843ca3efe02dc8ce7faf72f9103d927c2b2729b76202448dfbae2870d542bf`). Its omitted source caused5 canonical-theme failures. Integrated without changing original worktree. Exact Core approval/PR binding is recorded in `docs/architecture/acr/ACR-PRESCHOOL-418-CANONICAL-TENANT-PROVIDER-20261023.md`; local approved-core guard PASS. No other Core file changed.

Other CI root causes and minimal repairs:

- Finance page tests used the old unscoped GET/command fixture and payment dialog. Tests now select an explicit permitted branch, reconcile actor/tenant context, assert branch on commands and retain/assert operation key in storage. Same business assertion intent; no default branch introduced.
- Suspended-tenant and booking fixtures returned no public actor RPC result. Updated the RPC adapters rather than adding legacy `.or` query mocks or changing booking/runtime authorization. Suspended actor still returns null and causes no direct table fallback. Booking suite9/9 PASS.
- Related shell test expected fabricated `dev-tenant`. It now checks the approved fail-closed context contract and complete valid context DTO.
- CodeQL alert1068 crossed the shared PremiumSelect callback from unrelated Healthcare options into payment method. The Product persistence boundary now reconstructs only the three already-approved method literals and rejects undeclared runtime values before key allocation/storage. No suppression, scan reduction or accounting change. Negative tests cover strings/objects outside the enum. Actual remote CodeQL result on the new source remains pending.

Executed validation: `FINAL_CI_REPAIR_JEST.json` **6 suites84 tests PASS**; `PROVIDER_RELATED_FINAL_JEST.json` **3 suites51 tests PASS**, overlapping some contract/provider cases (do not sum). Full strict TypeScript and scoped ESLint PASS. Browser payment recovery with the new provider/method boundary PASS at `../http-2026-10-23T04-32-59-191Z/PROVIDER_PAYMENT_BROWSER_EVIDENCE.json`: exact operation key/payment/receipt IDs, persisted Finance rows unchanged, no page errors. Cold runtime/hydration failures are retained separately, not relabelled PASS.

Additional remote status on old SHA: affected test suite failed14 cases (the cases addressed above); Baseline Comparison consequently BLOCK. Semgrep full scan474 findings, **0 on changed paths** per downloaded SARIF path reconciliation; no baseline assertion is inferred without source comparison. AutoMove RC NOT_PROVEN and full Real DB Business E2E still in progress at capture. Do not repair unrelated modules/schema/workflows or claim these gates PASS.

Preview of old SHA is Ready at `https://bella-spa-lrnnpejge-bella-spa-s-projects.vercel.app`; this is infrastructure readiness, not verified Preschool operation on preview. The next push requires its own preview/check evidence. No merge, Production migration/deploy or ruleset change performed.
