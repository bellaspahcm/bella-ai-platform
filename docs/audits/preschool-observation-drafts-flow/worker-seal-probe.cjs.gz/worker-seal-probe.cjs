const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const dir='docs/audits/preschool-observation-drafts-flow/',file='src/app/dashboard/education/grades/page.tsx';
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const before=JSON.parse(fs.readFileSync(dir+'native-before.json')),after=JSON.parse(fs.readFileSync(dir+'native-after.json'));
const evidence=JSON.parse(fs.readFileSync(dir+'verification.json'));
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8'});
const original=git('show','HEAD:'+file),source=fs.readFileSync(file,'utf8');
assert.equal(before.testSha256,after.testSha256);assert.equal(hash(fs.readFileSync(dir+'observation-browser.cjs')),before.testSha256);assert.equal(after.summary.passed,28);assert.equal(before.summary.errors,0);assert.equal(after.summary.errors,0);
const section=(text,start,end)=>text.slice(text.indexOf(start),text.indexOf(end,text.indexOf(start)));
const preserved={
referenceDataAndTypes:original.slice(0,original.indexOf('export default function'))===source.slice(0,source.indexOf('export default function')),
tenantDetection:section(original,'  // Tenant detection','  // Filtered roster')===section(source,'  // Tenant detection','  // Filtered roster'),
rosterAndNavigation:section(original,'  // Filtered roster','      {/* ── MODAL 2:')===section(source,'  // Filtered roster','      {/* ── MODAL 2:').replace('                  selectObservationChild(inspectedStudent.id);\n',''),
options:JSON.stringify([...original.matchAll(/<option[^>]*>[\s\S]*?<\/option>/g)].map(m=>m[0]))===JSON.stringify([...source.matchAll(/<option[^>]*>[\s\S]*?<\/option>/g)].map(m=>m[0])),
dialogFocusProps:JSON.stringify([...original.matchAll(/<Dialog(?:Content)?\s[^>]*>/g)].map(m=>m[0]))===JSON.stringify([...source.matchAll(/<Dialog(?:Content)?\s[^>]*>/g)].map(m=>m[0])),
onlyOwnedTrackedSource:git('diff','--name-only').trim()===file,
};
for(const [label,value] of Object.entries(preserved))assert.equal(value,true,label);
const browser=dir+'.cache/browser/chrome-headless-shell-win64/chrome-headless-shell.exe';
const baselineBrowser=JSON.parse(fs.readFileSync(dir+'dependency-provenance.json')).executableSha256;
assert.equal(hash(fs.readFileSync(browser)),baselineBrowser);
evidence.result='PASS_SCOPED_UI';evidence.completedAt=new Date().toISOString();evidence.branch=git('branch','--show-current').trim();evidence.head=git('rev-parse','HEAD').trim();
evidence.browserRuns=[before,after].map(r=>({command:r.command,commandSha256:r.commandSha256,exit:r.exitCode,stdout:JSON.stringify({phase:r.phase,...r.summary})+'\n',stderr:'',summary:r.summary,receipt:r.phase==='before'?'native-before.json':'native-after.json',testSha256:r.testSha256,sourceSha256:r.sourceSha256,globalsSha256:r.globalsSha256,assertions:{pass:r.results.flatMap(x=>x.assertions).filter(a=>a.result==='PASS').length,fail:r.results.flatMap(x=>x.assertions).filter(a=>a.result==='FAIL').length,error:r.results.flatMap(x=>x.assertions).filter(a=>a.result==='ERROR').length},journeys:Object.fromEntries(r.results.map(x=>[x.journey+'-'+x.theme+'-'+x.device,x.result]))}));
for(const run of evidence.browserRuns){run.stdoutSha256=hash(run.stdout);run.stderrSha256=hash(run.stderr);}
evidence.sameTestSha256=before.testSha256;evidence.preservation=preserved;evidence.defaultValues={child:'STU-001',domain:'Ngôn Ngữ & Giao Tiếp',progression:'Đạt kỳ vọng',skill:'',note:'',photosCount:1};
evidence.contrast=after.results.flatMap(r=>(r.contrast||[]).map(c=>({theme:r.theme,device:r.device,...c})));
assert.equal(evidence.contrast.length,4);assert.ok(evidence.contrast.every(c=>c.minimumRatio>=4.5));
evidence.screenshots=['light-desktop','dark-desktop','light-mobile','dark-mobile'].map(context=>{const filename='draft-'+context+'.png';const data=fs.readFileSync(dir+filename);return{filename,sha256:hash(data),bytes:data.length,visualReview:'Selected Trần Bảo Ngọc, distinctive B fields and honest unavailable status visible. Mobile footer requires dialog scrolling.'};});
evidence.sourceDiff=git('diff','--',file);evidence.cleanup='Browser and all 28 fresh contexts closed; loopback server closed by finally; browser command exited. Task-local ignored build/browser cache retained; no external app/DB/Auth/network.';
evidence.nativeLifecycle='Lead-owned history/counters/readback; no worker claim or modification.';
evidence.scope='Only owned observation state, field event setters, profile child capture and truthful note. No persistence feature. Existing 503/core/security/runner sources unchanged (tracked diff restricted to owned page).';
fs.writeFileSync(dir+'verification.json',JSON.stringify(evidence,null,2)+'\n');
const minimum=Math.min(...evidence.contrast.map(c=>c.minimumRatio));
fs.writeFileSync(dir+'PR_BODY.md',`Profile observation actions previously opened the last active child, and changing the child selector reused one shared form. The preview now captures the profile child before closing it and keeps independent component-lifetime drafts by existing sample child ID. Every field uses an immutable functional update; exact defaults remain unchanged. Global reopen keeps the active child. Save stays honestly unavailable, and reload discards every draft. The note now describes per-child retention.\n\nValidation: the NEW actual-component/shared-Dialog browser test ran unchanged before and after across seven journeys in light/dark desktop/mobile (28 fresh contexts per run). Baseline: 8 PASS, 20 legitimate FAIL, zero harness errors. After: 28 PASS, zero failures/errors. Both runs: zero page errors, unexpected requests and downloads. Test SHA-256: ${before.testSha256}. Four screenshots were visually reviewed; changed-note contrast passes all four contexts, raw minimum ${minimum}. Focused ESLint, Education TypeScript, test syntax and whitespace checks exit 0 (ESLint emits the existing ignore-file migration warning).\n\nEvidence: native-before.json, native-after.json and verification.json contain actual steps, counters, hashes, diff, preservation checks and contrast samples. Constants/records/options, roster state logic, modal focus props and tenant detection remain unchanged. Only grades/page.tsx runtime source changed. No DB/Auth/storage/save capability or full Next runtime proof. Parent RLS FAIL; Course authorization BLOCKED; UI→DB NOT_PROVEN; Pre-Go-Live BLOCKED. Lead owns native-history review and publication. No stage/commit/push/PR/deploy performed.\n`);
console.log(JSON.stringify({preserved,minimumContrast:minimum,testHash:before.testSha256,checks:evidence.checks.map(c=>({command:c.command,exit:c.exit}))}));
